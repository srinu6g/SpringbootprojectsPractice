package com.spring.annotation;

import org.springframework.stereotype.Component;

@Component
public class Organization {
	
	private String branch;
	private int totalStudents;
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public int getTotalStudents() {
		return totalStudents;
	}
	public void setTotalStudents(int totalStudents) {
		this.totalStudents = totalStudents;
	}
	

}

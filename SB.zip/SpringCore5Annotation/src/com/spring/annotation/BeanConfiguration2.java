package com.spring.annotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfiguration2 {
	
	@Bean("stu3")
	public Student getStudentDetails3()
	{
		return new Student();
		
	}
	@Bean("stu4")
	public Student getStudentDetails4()
	{
		return new Student();
		
	}
	
	
	
	
	
	
	

}

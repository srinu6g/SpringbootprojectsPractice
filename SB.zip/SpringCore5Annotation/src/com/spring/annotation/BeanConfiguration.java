package com.spring.annotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.*")
public class BeanConfiguration {
	
	@Bean("stu1")
	public Student getStudentDetails()
	{
		Student s1=new Student();
		s1.setSid(101);
		s1.setSname("praveen");
		s1.setMarks(100);
		return s1;
		
	}
	@Bean("stu2")
	public Student getStudentDetails2()
	{
		Student s2=new Student();
		s2.setSid(102);
		s2.setSname("srinivas");
		s2.setMarks(80);
		return s2;
		
		
		
	}
	
	
	
	
	
	
	

}

package com.spring.annotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.autowired.Address;
import com.spring.autowired.BeanConfiguration3;
import com.spring.autowired.Employee;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	ApplicationContext context= new AnnotationConfigApplicationContext(BeanConfiguration3.class);
	
	/*Student s1=(Student) context.getBean("stu1");
	System.out.println("********student 1 details *********");
	System.out.println(s1);
	System.out.println(s1.getSid());
	System.out.println(s1.getSname());
	System.out.println(s1.getMarks());
	
	Student s2=(Student) context.getBean("stu2");
	System.out.println("********student 1 details *********");
	System.out.println(s2);
	System.out.println(s2.getSid());
	System.out.println(s2.getSname());
	System.out.println(s2.getMarks());
	
	System.out.println("********Organization Detaisl*********");
	
	Organization org=context.getBean(Organization.class);
	System.out.println(org);
	System.out.println(org.getBranch());
	
	System.out.println(org.getTotalStudents()); */
	
  Employee emp =context.getBean(Employee.class);
  
	System.out.println(emp);
	System.out.println(emp.getEname());

	System.out.println(emp.getAddress().getCity());
	System.out.println(emp.getAddress().getPincode());
	
	
	}

}

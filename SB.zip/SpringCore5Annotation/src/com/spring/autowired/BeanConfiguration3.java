package com.spring.autowired;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@ComponentScan("com.*")
public class BeanConfiguration3 {
	
	
	@Bean("CHN")
	public Address getAddress2()
	{
		Address a2=new Address();
		a2.setCity("chennai");
		a2.setPincode(23244);
		return a2;
		
	}
	@Bean("BAN")
	public Address getAddress3()
	{
		Address a3=new Address();
		a3.setCity("Bangalore");
		a3.setPincode(23244);
		return a3;
		
		
		
	}

}

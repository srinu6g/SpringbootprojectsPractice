package com.demo.jpa.example.Patient;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Component
public interface PatientRepository extends JpaRepository<Patient,String> {
	
	      //*** custom Query methods*******//
	
	//Get Details of Patients by Age i.e. Single Column
	
	
			List<Patient> findByAge(int age);
			
	/* : Fetch Data with Age and Gender Columns.
			• Age is 28
			• Gender is Female 	 */	
			
			List<Patient>findByAgeAndGender(int age,String gender);
			
	//########## NativeSqL queries ###############//
			
			// getting all patient details by using nativeSql
			@Query(value = "select * from patient" , nativeQuery = true)
			List<Patient>gettingAllDetails();
			
	// Get All Patient with Email Id pass parameter as emqil
			
		@Query(value = "select * from patient where email=?1",nativeQuery =true)
		List<Patient>gettingAllDetailsBasedOnEmail(String email);
		
		// Get All Patients with Age and Gender
		
		@Query(value ="select * from patient where age=?1 And gender=?2",nativeQuery = true)
		List<Patient>gettingPatientsAgeAndGender(int age,String gender);
		
		// Get All Patients with Age or Gender
		
		@Query(value ="select * from patient where age=?1 or gender=?2",nativeQuery = true)
		List<Patient>gettingPatientsAgeOrGender(int age,String gender);
		
		
		//%%%%%%% Named Query param %%%%%%%%%%%%%%%%%%%%%%%%%//
		
		
		//get All Patient with Email Id pass parameter as emqil
		
		@Query(value = "select * from patient where email=:email",nativeQuery = true)
		List<Patient>getPatientEmail(@Param("email") String x);
		
		//// Get All Patients with Age and Gender
		
		@Query(value = "select * from patient where age=:age and gender=:gender",nativeQuery = true)
		List<Patient>getPatientAgeAndGenderNamed(@Param("gender") String x,@Param("age") int r);
		
		// DML operations//
		
	
		    @Query(value = "INSERT INTO patient(name, age, gender, contact, email) VALUES(?1, ?2, ?3, ?4, ?5)", nativeQuery = true)
		    int addOneMoreRecord(String name, int age, String gender, long contact, String email);	
		    
		    
		    // sorting
		    
		   
		   
		    	// i want only age coloun 
		    
		    @Query(value = "select * from patient where age=:age" ,nativeQuery = true)
		    List<Patient> gettingAgeColumn(@Param("age")  int age);
		    
		    
		    
			
		    

}

package com.demo.jpa.example.Patient;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.mapping.Array;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Component
@EnableTransactionManagement
@EnableJpaRepositories
public class PatientOperations {
	
	@Autowired
	PatientRepository repo;
	
	// based on primary key column
	
	
	//1. Add Single Patient Details 
	public void addSinglePatient()
	{
		Patient p1=new Patient();
		p1.setAge(24);
		p1.setContact(13424334);
		p1.setEmail("srinivas@gmail.com");
		p1.setGender("M");
		p1.setName("srinivas");
		
		repo.save(p1);
	
	}
	
	// 2. Add More Than One Patient Details 
	
		public void addMorePatients() {
			
			Patient p7=new Patient();
			p7.setAge(89);
			p7.setContact(15642334);
			p7.setEmail("narasayya@gmail.com");
			p7.setGender("M");
			p7.setName("narasayya");
			
			
			Patient p8=new Patient();
			p8.setAge(16);
			p8.setContact(8673334);
			p8.setEmail("sony@gmail.com");
			p8.setGender("F");
			p8.setName("sony");
			
			
			Patient p9=new Patient();
			p9.setAge(35);
			p9.setContact(984594334);
			p9.setEmail("swami@gmail.com");
			p9.setGender("M");
			p9.setName("swami");
			
			
			
			List<Patient> l1=new ArrayList<>();
			l1.add(p7);
			l1.add(p8);
			l1.add(p9);
			
			
			
			repo.saveAll(l1);
			
		}
		// req 3. Update Patient Details  
		
		public void updateRecord()
		{
			Patient p1=new Patient();
			p1.setAge(35);
			p1.setContact(984594334);
			p1.setEmail("ram@gmail.com");
			p1.setGender("M");
			//p1.setName("rapo");
			
			// already this above record is avilable in  a table
			// i want to update name as rapo to "ramPotineni"
			
			p1.setName("ramPotineni");
			
			repo.save(p1);
		}
		
		
		// 4. Select Single Patient Details 
		
		public void gettingBAsedOnEmaild(String email)
		{
		 Patient   info   =  repo.findById(email).get();
		 System.out.println(info);
			
		}
		
		//  findall() // retrive multiple information
		// delete all() // delete multiple info
		
		
		// 5. Select multiple Patient Details 
		
		public void gettingAll()
		{
			  List<Patient> all=  repo.findAll();
			  System.out.println(all);
		}
		
		// i want delete single patient details
		
		public void deleteSinglePatient(String email)
		{
		         repo.deleteById(email);
		}
		
		// custom query methods 
		
		// Get Details of Patients by Age i.e. Single Column 
		
		// non primary key columns  
		
		
		public void gettingDetailsBasedOnAge()
		{
			List<Patient> l23=repo.findByAge(24);
			System.out.println(l23);
		}
		
		public void gettingDetailsBasedOnAgeAndGender()
		{
			List<Patient> l4=repo.findByAgeAndGender(23,"F");
			System.out.println(l4);
		}
		
		
		// native sql and jpql
		
		// getting all patient details // generally we use findAll()
		// but how to deal native sql
		
		public void getDetails()
		{
			List<Patient> lw=repo.gettingAllDetails();
			System.out.println(lw);
		}
		
		
		/* how to passs value dynamically into a native sql queries 
		// jpa provides two ways
		//1)INDEX query para,meteres 
		//2)NAMED query parametrs
		
		
		// Get All Patient with Email Id pass parameter as emqil 
		//using NativeSql 
		
		public void gettingEmailDetails()
		{
			List<Patient> h1=repo.gettingAllDetailsBasedOnEmail("srinivas@gmail.com");
			System.out.println(h1);
		}
		//Get All Patients with Age and Gender
		
		public void gettingEmailDetailsAgeAndGenderIndex()
		{
			List<Patient> h9=repo.gettingPatientsAgeAndGender(24,"M");
			System.out.println(h9);
		}
		
		// Get All Patients with Age or Gender
		
		public void gettingEmailDetailsAgeOrGenderIndex()
		{
			List<Patient> h6=repo.gettingPatientsAgeOrGender(24,"F");
			System.out.println(h6);
		} */
		
		// Named Query param ///
		
		
		public void gettingEmail() {
			
		List<Patient> n1=	repo.getPatientEmail("meghana@gmail.com");
		System.out.println(n1);
			
		}
		
		public void gettingageandGender() {
			
			List<Patient> n2=	repo.getPatientAgeAndGenderNamed("F",29);
			System.out.println(n2);
				
			}
		
		
		
		// PAGINATION ////
		
		
		
		
		public void getDataPaging()
		{
			//Pageable req = Pageable.ofSize(2);
			PageRequest req1=PageRequest.of(0, 2);
			PageRequest req2=PageRequest.of(0, 3,Direction.ASC,"name");
		List<Patient> l1=	repo.findAll(req2).getContent();
		System.out.println(l1);
		}
		
		
	
		
		public void arrangingBasedOnAgeDeScNamesSorting()
		{
			Page<Patient> l=repo.findAll(Pageable.ofSize(2));
			System.out.println(l);
			
			
			
		}
		
		// sorting
		
		
		// i want get all patient details based on age
		
		public void gettingAgeDetails()
		{
			
			List<Patient> l=repo.findAll(Sort.by(Direction.ASC, "email"));
			System.out.println(l);
		}
		
		// now am retriving data based on age and name
		
		
		
		// i want only age coloun 
		
		public void xyz()
		{
			List<Patient> li= repo.gettingAgeColumn(89); 
			System.out.println(li);
		}
	
		// paging 
		
		public void pagingconcept()
		{
			List<Patient> p=repo.findAll(Pageable.ofSize(2)).getContent();
			
				System.out.println(p);
		}
		
	// req 	i want all the records with paging
		
		public void pagingconcept2()
		{
			PageRequest req=PageRequest.of(0, 4);
			List<Patient> p=repo.findAll(req).getContent();
			
				System.out.println(p);
		}
		
		
		public void  pagingConceptslearning()
		{
			List<Patient> p=repo.findAll(Pageable.ofSize(2)).getContent();
			System.out.println(p);
		
		}
		// 9/2 tell me total pages 5
		
		public void  pagingConceptslearning2()
		{
			PageRequest req=PageRequest.of(2, 3);
			List<Patient> p=repo.findAll(req).getContent();
			System.out.println(p);
		
		}
		
		public void  pagingConceptslearning3()
		{
			PageRequest req=PageRequest.of(0, 3,Sort.by(Direction.ASC,"name"));
			List<Patient> p=repo.findAll(req).getContent();
			System.out.println(p);
		
		}
		public void  pagingConceptslearning4()
		{
			PageRequest req=PageRequest.of(0, 3, Sort.by("asds"));
			List<Patient> p=repo.findAll(req).getContent();
			System.out.println(p);
			
			
			
		
		}
		
		
	
}

package com.demo.jpa.example.Patient;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.jpa.example.JpaConfiguration;

public class Testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// create container object
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(JpaConfiguration.class);
		context.refresh();
		
		PatientOperations op=context.getBean(PatientOperations.class);
		
		//op.addSinglePatient();
	    // op.addMorePatients();
		//op.updateRecord();
		//op.gettingBAsedOnEmaild("ramaa@gmail.com");
		//op.gettingAll();
		//op.deleteSinglePatient("ram@gmail.com");
		//op.gettingDetailsBasedOnAge();
		//op.gettingDetailsBasedOnAgeAndGender();
		//op.getDetails();
		//op.gettingEmailDetails();
		//op.gettingEmailDetailsAgeAndGenderIndex();
		
		//op.gettingEmailDetailsAgeOrGenderIndex();
		
		//op.gettingEmail();
		//op.gettingageandGender();
		
		/* sorting */
		//op.getData();
		//op.getDataDesc();
		//op.getDataDescAgeAndName();
		
		//********************** Pagination************************//
		
		//op.getDataPaging();
		
		//System.out.println(op.addmoreRecord());
		
		//op.xyz();
	     //op.pagingconcept();
	     //op.pagingconcept2();
	     
	    // op.pagingConceptslearning();
	     
	    op.pagingConceptslearning3();
		
	}

}

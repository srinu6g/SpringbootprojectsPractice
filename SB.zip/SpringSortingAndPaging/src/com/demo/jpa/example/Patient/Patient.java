package com.demo.jpa.example.Patient;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity//table name is now "patient" for ex i want to change my table name instead of Entity class name
// follow like @Entity(name="rama")
public class Patient {
	@Column
	private String name;
	@Column
	private int age;
	@Column
	private String gender;
	
	@Column
	private long contact;
	
	@Id
	@Column
	private String email;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Patient [name=" + name + ", age=" + age + ", gender=" + gender + ", contact=" + contact + ", email="
				+ email + "]";
		
	}
	
	
	
	
	

}

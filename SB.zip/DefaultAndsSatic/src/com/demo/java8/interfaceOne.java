package com.demo.java8;

public interface interfaceOne {
	
     public void abstractOne();
     public void abstractTwo();	
      public default  String defaultOne()
      {
    	 System.out.println("Interface one default method one");
		return null; 
    	  
      } // interface level default method implementation
      
      public static String sayHello()
      {
    	  System.out.println("Heoolo super gutu");
    	  return null;
      }
      public static void sayHello(int a)
      {
    	  System.out.println("Heoolo super gutu your age");
      }
      
      public static void sayHello(String name)
      {
    	  System.out.println("Heoolo super gutu your good name please ");
      }
      
      

}


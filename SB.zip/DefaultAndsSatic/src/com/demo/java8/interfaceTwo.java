package com.demo.java8;

public interface interfaceTwo {
	
	public void abstarctThree();
	public void abstarctFour();
	
	public default  String defaultOne()
    {
	
  	 System.out.println("Interface two default method one");
		return null; 
  	  
    }
	
	   
}

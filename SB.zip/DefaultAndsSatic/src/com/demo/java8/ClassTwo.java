package com.demo.java8;

public class ClassTwo  implements interfaceOne{

	@Override
	public void abstractOne() {
		// TODO Auto-generated method stub
		System.out.println("Classstwo overide abstaract methodOne");
	}

	@Override
	public void abstractTwo() {
		// TODO Auto-generated method stub
		System.out.println("Classtwo overide abstaract methodtwoS");
	}
	
	
	
	

}

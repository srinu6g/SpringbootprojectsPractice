package com.demo.java8;
public class ClassOne  implements interfaceOne
{

	@Override
	public void abstractOne() {
		// TODO Auto-generated method stub
		System.out.println("Classsone overide abstaract methodOne");
	}

	@Override
	public void abstractTwo() {
		
// TODO Auto-generated method stub
		System.out.println("Classsone overide abstaract methodTwo");
	}
	// my class level   default method implementation
    
	
		

	
}
/*USECASE::  you are overridddinf default methods in your class level implementation 
 * jvm is always highest priority is always class level implementation
 * 
 * 
 * 
 * 
 */

package com.demo.java8;

public class ClassFour implements interfaceThree {

	@Override
	public void abstarctSix() {
		interfaceThree.college();
		// TODO Auto-generated method stub
		System.out.println("Overriide clasThree level");
	}
	
	public static void University()
	{
		interfaceThree.college();
		System.out.println("Am good in University level");
	}
	
	

}

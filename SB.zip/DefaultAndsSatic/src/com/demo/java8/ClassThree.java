package com.demo.java8;

public class ClassThree implements interfaceOne,interfaceTwo {

	@Override
	public void abstarctThree() {
		// TODO Auto-generated method stub
		System.out.println(" Class therre override inertfaceTwo abstarct methods");
	}

	@Override
	public void abstarctFour() {
		// TODO Auto-generated method stub
		System.out.println(" Class therre override inertfaceTwo abstarct methods");

		
	}

	@Override
	public void abstractOne() {
		// TODO Auto-generated method stub
		System.out.println(" Class therre override inertfaceOne abstarct methods");

	}

	@Override
	public void abstractTwo() {
		// TODO Auto-generated method stub
		System.out.println(" Class therre override inertfaceOne abstarct methods");

	}
	 public String defaultOne()
     {
		 interfaceOne.super.defaultOne();
		 interfaceTwo.super.defaultOne();
		 return null; 
     }
	 
	}

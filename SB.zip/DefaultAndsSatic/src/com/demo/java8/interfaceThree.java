package com.demo.java8;

public interface interfaceThree {
	
	public void abstarctSix();
	
	public  static void college()
	{
		System.out.println("College level you are naughty");
	}

}

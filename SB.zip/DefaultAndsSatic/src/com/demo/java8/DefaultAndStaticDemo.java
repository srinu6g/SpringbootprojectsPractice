package com.demo.java8;

public class DefaultAndStaticDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		  ClassOne one =new ClassOne(); //one.defaultOne();// output :: hello
		 System.out.println(one.defaultOne());
		  one.abstractOne(); 
		  one.abstractTwo();
		  
		  
		 
		 
		  
			/*
			 * // second class information System.out.println("**********************");
			 * ClassTwo two=new ClassTwo(); two.abstractOne(); two.abstractTwo();
			 * 
			 * System.out.println("********ClassThree  implementation *****************");
			 * 
			 * ClassThree three=new ClassThree(); three.defaultOne();
			 * 
			 * System.out.println("ClassFoue detAILS********"); ClassFour four=new
			 * ClassFour(); four.abstarctSix(); four.University();
			 * 
			 * 
			 */

	}

}

package com.spring.setterAndConst;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context=new AnnotationConfigApplicationContext(BeanConfiguraion.class);
		/*Address add=(Address) context.getBean(Address.class);
		System.out.println(add);
		System.out.println(add.getCity());
		System.out.println(add.getZip()); */
		
		System.out.println("*******  Employee Details  *****");
	Employee emp=(Employee)	context.getBean(Employee.class);
	System.out.println(emp);
	System.out.println(emp.getEname());
	System.out.println(emp.getAddress().getCity());
	System.out.println(emp.getAddress().getZip());
	
	
	
	}

}

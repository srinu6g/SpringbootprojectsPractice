package com.spring.setterAndConst;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class Address {
	
	private String city;
	private int zip;
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getZip() {
		return zip;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}
	
	

}

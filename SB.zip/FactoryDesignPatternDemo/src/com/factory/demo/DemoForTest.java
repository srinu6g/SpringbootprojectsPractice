package com.factory.demo;

import com.factory.demo.impl.Car;
import com.factory.demo.impl.VehicleType;

public class DemoForTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Car c1=new Car();// tightcoupling
		
		Car c2=(Car) VehicleFactory.getVehicleInformation(VehicleType.Car);
		c2.drive();

	}

}

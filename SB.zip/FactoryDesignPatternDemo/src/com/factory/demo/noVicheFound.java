package com.factory.demo;

public class noVicheFound extends RuntimeException {

	public noVicheFound(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	
	
	

}

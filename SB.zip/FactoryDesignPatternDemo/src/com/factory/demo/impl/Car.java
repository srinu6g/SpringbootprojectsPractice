package com.factory.demo.impl;

import com.factory.demo.Vehicle;

public class Car implements Vehicle {
	
	@Override
	public void drive() {
		// TODO Auto-generated method stub
		System.out.println("Car am driving");
	}
	

}

package com.factory.demo.impl;

public enum VehicleType {
	
	Bike,Car,Bus;

}

package com.factory.demo;

public interface Vehicle {
	
	public void drive();
	
	

}

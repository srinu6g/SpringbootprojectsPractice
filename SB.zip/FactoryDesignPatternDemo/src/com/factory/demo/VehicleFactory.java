package com.factory.demo;

import com.factory.demo.impl.Bike;
import com.factory.demo.impl.Bus;
import com.factory.demo.impl.Car;
import com.factory.demo.impl.VehicleType;

public class VehicleFactory {
	
	
	
	private VehicleFactory() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static Vehicle getVehicleInformation(VehicleType vehicleType)
	{
		
		switch(vehicleType)
		{
		case Car: 
			return new Car();
		
		case Bike:
			return new Bike();
		
		case Bus: 
			return new Bus();
		
		default : throw new noVicheFound("Vechicle not found");
		}
		
		
	
		
		
		
	}
	

}

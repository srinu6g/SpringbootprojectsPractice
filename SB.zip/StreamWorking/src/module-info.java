/**
 * 
 */
/**
 * @author 91891
 *
 */
module StreamWorking {
}
package com.stteram.api.explain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamFullFilled {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Employee> empList=new ArrayList<>();
		
		
		
		empList.add(new Employee(1, "abc", 28, 123, "F", "HR", "Blore", 2020));

		empList.add(new Employee(2, "xyz", 29, 120, "F", "HR", "Hyderabad", 2015));

		empList.add(new Employee(3, "efg", 30, 115, "M", "HR", "Chennai", 2014));

		empList.add(new Employee(4, "def", 32, 125, "F", "HR", "Chennai", 2013));

		empList.add(new Employee(5, "ijk", 22, 150, "F", "IT", "Noida", 2013));

		empList.add(new Employee(6, "mno", 27, 140, "M", "IT", "Gurugram", 2017));

		empList.add(new Employee(7, "uvw", 26, 130, "F", "IT", "Pune", 2016));

		empList.add(new Employee(8, "pqr", 23, 145, "M", "IT", "Trivandrum", 2015));

		empList.add(new Employee(9, "stv", 25, 160, "M", "IT", "Blore", 2010));
		
		
		System.out.println(empList);
		
		//  Printing Names of All Departments
		
	Set<String> detpnames=	    empList.stream() // creation of stream object
		    .map(names->names.getDeptName())// intermedizte operaton
		    
		    .collect(Collectors.toSet());   // ternimal operation
		
		System.out.println(detpnames);
	// 2nd way
		
		List<String> detpnames2=	    empList.stream() // creation of stream object
			    .map(names->names.getDeptName())// intermedizte operaton
			    
			    .collect(Collectors.toList());   // ternimal operation
			
			System.out.println(detpnames2);
		
		// Printing Employee Details by Age Criteria
			//// Print employee details whose age is greater than 28
			
				
		List<Employee> ageofEmployees= empList.stream()// crestion of stream
			 .filter(emp->emp.getAge()>28)
			// .forEach(System::out.println);
			 .toList();
		System.out.println(ageofEmployees);
			 
	        
	        
	   //// Find maximum age of employee

          		Employee maxAge=		empList.stream()
          				.max((e1,e2)-> e1.getAge()-e2.getAge()) .get();
          				
          		System.out.println(maxAge);
          		
	        
	  ////  Printing Average Age of Male and Female Employees

      // key -value : you want group the employee is male or female and follewd by 
          //		average age
	        
          			
       Map<String,Double>  avgage=  		empList.stream()
                .collect(Collectors.groupingBy(emp->emp.getGender(),Collectors.averagingDouble(e1->e1.getAge())));
	        
	        
	    System.out.println(avgage);  
	    
	    
	    
	    //calclate total salry of each department
	    
	    	Map<String,Long>	 totasaldept=	empList.stream()
	    	
	    			.collect(Collectors.groupingBy(emp->emp.getDeptName(),Collectors.summingLong(e1->e1.getSalary())));
	        
	        System.out.println(totasaldept);
	        
	        
	        //// Print the number of employees in each depart
	        
	    Map<String,Long> counteachdept=    empList.stream()
	        .collect(Collectors.groupingBy(sri->sri.getDeptName(),Collectors.counting()));
	        
	       System.out.println(counteachdept); 
	       
	       
	       //// Find the oldest employee
	       
	       
	       Employee maxAge1=		empList.stream()
     				.max((e1,e2)-> e1.getAge()-e2.getAge()) .get();
     				
     		System.out.println(maxAge1);
	        
	    //// Find the youngest employee   
	        
     		 Employee minAge1=		empList.stream()
      				.min((e1,e2)-> e1.getAge()-e2.getAge()) .get();
      				
      		System.out.println(minAge1);
 	        
	     // Find the youngest  male  employee  
      		
      	Employee youngmale= 	empList.stream()
      		.filter(e1->e1.getGender().equalsIgnoreCase("f"))
      		.min((e1,e2)-> e1.getAge()-e2.getAge()).get();
      	System.out.println("Youngest female person");	
      	System.out.println(youngmale);
      	
      	/// Find employees whose age is greater than 30 and less than 20
      	
      	
   Map<Boolean,List<Employee>> agepartion=   empList.stream()
      .collect(Collectors.partitioningBy(e1->e1.getAge()>30));
      System.out.println(agepartion);
	        
	        
	        
	   //// Find if there are any employees from the HR Department     
	        
	    Employee e0=   empList.stream()
	       
	       . filter(e1->e1.getDeptName().equalsIgnoreCase("HR"))
	       .findAny().get();
	      System.out.println(e0);  
	      
	   //Finding Departments with Over 3 Employees   
	      
	      Employee e8=   empList.stream()
	   	       
	   	       . filter(e1->e1.getDeptName().equalsIgnoreCase("IT"))
	   	       .skip(4)
	   	       .findFirst().get();
	   	      System.out.println(e8);
	   	      
	   	      // finding and Sorting Employees by City is bangalore
	   	      
	   	   List<Employee> mna=  empList.stream()
	   	      .filter(e1->e1.getCity().equalsIgnoreCase("chennai"))
	   	      .sorted(Comparator.comparing(Employee::getName))
	   	      .toList();
	   	   System.out.println();
	   	   System.out.println(mna);
	   	   
	   	 // counting total employees working
	   	long l=   empList.stream().count();
	   	   
	   	System.out.println(l);   
	   	   
	   	   
	   	//Map<K, V>    i want reteuve depart and value how many people working
	   	// 
	   //	empList.stream().sorted(comparator1.thenComparing(comparator2)).forEach(System.out::println);
	   	
	   	// Sorting Employees by Name and Age
	   	
	   	Comparator<Employee> compare1=Comparator.comparing(Employee::getAge);
	   	System.out.println(compare1);

	   	   
	   	Comparator<Employee> compare2=Comparator.comparing(Employee::getName);
	   	System.out.println(compare2);
	   	
	   List<Employee> sor=	empList.stream().sorted(compare1.thenComparing(compare2)).toList();
	   	
        System.out.println(sor);
        
        
        // Printing Average Salary of Each Department
	   	    
	   	   
	   	   
	   	   //empList.stream().collect(Collectors.toMap(Employee::getDeptName, Collectors.averagingLong(Employee::getSalary)));
	   	   
	  Map<String,Double>  avgdept=	    empList.stream().collect(Collectors.groupingBy(Employee::getDeptName,Collectors.averagingLong(Employee::getSalary)));
	   	
	   	   System.out.println(avgdept);
	   	   
	   	   
	  // i want all departmrnts 
	   	   
	   	   empList.stream()
	   	   .map(Employee::getDeptName)
	   	   .forEach(System.out::println);
	   	   
	   	   // second highest sal
	   	   
	   	   
	   	   System.out.println("HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH");
	   	   	
	 Optional<Employee> sec=	   empList.stream()
	   	   .sorted(Comparator.comparingDouble(Employee::getSalary).reversed())
	   	   .skip(1)
	   	   .findFirst();
	 
	 if(sec.isPresent())
	 {
		 System.out.println("Second highest salary person"+sec);
	 }
	   	  
	   System.out.println(sec);	   
	   
	 
	   

	}

}

class Employee
{
	private int id;

	private String name;

	private int age;

	private long salary;

	private String gender;

	private String deptName;

	private String city;

	private int yearOfJoining;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getYearOfJoining() {
		return yearOfJoining;
	}

	public void setYearOfJoining(int yearOfJoining) {
		this.yearOfJoining = yearOfJoining;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", age=" + age + ", salary=" + salary + ", gender=" + gender
				+ ", deptName=" + deptName + ", city=" + city + ", yearOfJoining=" + yearOfJoining + "]";
	}

	public Employee(int id, String name, int age, long salary, String gender, String deptName, String city,
			int yearOfJoining) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.salary = salary;
		this.gender = gender;
		this.deptName = deptName;
		this.city = city;
		this.yearOfJoining = yearOfJoining;
	}
	

		
	
	
}

package com.stteram.api;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public record StreamOperaions() {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		List<Employee> l1=new ArrayList<>();
		
		l1.add(new Employee(7, "raja", "financial", 50000, 12-1-2019, 34));
		l1.add(new Employee(3, "rani", "technician", 67000, 29-5-2020, 40));
		l1.add(new Employee(9, "sita", "developer", 90000, 13-4-2019, 30));
		l1.add(new Employee(12, "rama", "testing", 20000, 17-12-2020, 24));
		l1.add(new Employee(23 ,"geeta", "devops", 300000, 12-1-2021, 14));
		l1.add(new Employee(2, "chaitu", "financial", 900000, 12-4-2019, 27));
		l1.add(new Employee(8, "himavanth", "devops", 430000, 12-8-2018, 29));
		l1.add(new Employee(6, "preeti", "developer", 50000, 12-4-2010, 42));
		l1.add(new Employee(1, "srinivas", "financial", 550000, 30-1-2020, 22));
		l1.add(new Employee(5, "pradeep", "ABC", 590000, 5-5-2021, 28));
		l1.add(new Employee(11, "yash", "developer", 50000, 16-8-2024, 56));
		
		System.out.println(l1);
	// the above code refers what am creating collection object and storing employee data	
		
		// streams 
		
		// req  i want all enames 
		
		
	List<String> empNames=	l1.stream()// this creation of stream objects
			.filter(emp->emp.getAge()>25)
		.map(emp->emp.geteName())// only empNaems [raja, rani, sita, rama, geeta, chaitu, himavanth, preeti, srinivas, pradeep, yash]
		
		.toList();
	System.out.println(empNames);
	
	
	//  count()
	System.out.println("*****************************");
				long salarywise=	l1.stream()
				.filter(emp->emp.getSalary()>50000)
				.count();
				System.out.println(salarywise);
	
	// limit()
			System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&");	
			List<Employee> employeesAll=	l1.stream()
					
				.limit(3)
				
				.toList();
			
		System.out.println(employeesAll);
			
	// skip()	
		
		System.out.println("####################&&&&&&&&&&&&");	
		List<Employee> employeesAllOrder=	l1.stream()
				
			.skip(5) // it will skippeing first 5 employee objectys
			
			.toList();
		System.out.println(employeesAllOrder);
	
		// anyMatch()
		
		boolean b1=l1.stream()
		.anyMatch(emp->emp.getEid()<1);
		
		System.out.println(b1);
		
		
		//allMatch()
		
		boolean b2=l1.stream()
				.allMatch(emp->emp.getEid()>7);
				System.out.println(b2);
				
				boolean b3=l1.stream()
						.noneMatch(emp->emp.getEid()<1);
						System.out.println(b3);
						
						
						// findAny()
						
						System.out.println("Working on finadAny()");
						
				Employee e1=	l1.stream()
					.findAny()
					.get();
				System.out.println(e1);
				
				
				// findFirst()
				
				Employee e2=	l1.stream()
						.findFirst()
						.get();
					System.out.println(e2);
					
					// sorted()
					
				List<String> allNamesDept	=l1.stream()
					.map(emp->emp.getDepartname()).sorted().toList();
				System.out.println(allNamesDept);
			
					
					// 
				

		List<Employee> rathod=	l1.stream()
					.sorted((e8,e9)->e8.getEid()-e9.getEid())
					.toList()
					
				;
		System.out.println(rathod);
						
						// 
		
	Employee maxsaalary=	l1.stream()
		.max((e8,e9)->e8.getEid()-e9.getEid()).get();
		System.out.println(maxsaalary);
	
		// collect() 
		// getting all employee names as list whose age is greater 25 
	List<String> empNamestwo=	l1.stream()
		.filter(emp->emp.getAge()>25) // age is greatethean 25
		.map(Employee::geteName)
		.collect(Collectors.toList());
	
		System.out.println(empNamestwo);
	
// iwant unique departnames 
		// one way
	
		List<String>  depat=		l1.stream()
				.map(Employee::getDepartname).distinct().toList();
	
	System.out.println(depat);
	
	// second way   
			Set<String> depatTwo=		l1.stream()
					.map(Employee::getDepartname)
					.collect(Collectors.toSet());
			System.out.println(depatTwo);
			
			
	// collect employee id's and salaries
			
		Map<Integer,Integer> idandsal=	l1.stream()
			.collect(Collectors.toMap(Employee::getEid,Employee::getSalary))
			;
	 System.out.println(idandsal);
	 
	 // summing ()  to caluclate i want ALL EMPLOYEE salaries
	 
	 
	
	Integer salr=	l1.stream()
		.collect(Collectors.summingInt(Employee::getSalary));
	
	
	System.out.println(salr);
	
	// now i want summerizing 
	
	IntSummaryStatistics summary=l1.stream()
	.collect(Collectors.summarizingInt(Employee::getSalary));
	
	System.out.println(summary);
	
	// please focus until now  tomorrow joining,grouping, method & constructor refference
	
	// i want all employeenames 
	
		List<String>	 empnames=		 l1.stream() // with the help of collection object using straem() we can create stream object
					 .map(Employee::geteName)
					 .collect(Collectors.toList());
	  
	System.out.println(empnames);
	
	//   i want  developers depatemnt  total salary 
	
	System.out.println("#############################################");
	   Map<String,Integer>   deptsal=   l1.stream()
			   .filter(e11->e11.getSalary()>150000)
	        .collect(Collectors.groupingBy(Employee::getDepartname,Collectors.summingInt(Employee::getSalary)));
	            
	System.out.println(deptsal);
	
	//  
	         String dept=         l1.stream()
	                  .map(Employee::getDepartname)
	                  .collect(Collectors.joining("&"));
	          System.out.println(dept);        
	
	

	//
	         
	
				
	}

}
//https://www.linkedin.com/pulse/unlocking-efficiency-exploring-java-8-stream-api-employee-kadam-xf2af
 class Employee
{
	 
	 private int eid;
	 private String eName;
	 private String departname;
	 private int salary;
	 private int joingDate;
	 private int age;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public String getDepartname() {
		return departname;
	}
	public void setDepartname(String departname) {
		this.departname = departname;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getJoingDate() {
		return joingDate;
	}
	public void setJoingDate(int joingDate) {
		this.joingDate = joingDate;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Employee(int eid, String eName, String departname, int salary, int joingDate, int age) {
		super();
		this.eid = eid;
		this.eName = eName;
		this.departname = departname;
		this.salary = salary;
		this.joingDate = joingDate;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", eName=" + eName + ", departname=" + departname + ", salary=" + salary
				+ ", joingDate=" + joingDate + ", age=" + age + "]";
	}
	 
	 
	
}




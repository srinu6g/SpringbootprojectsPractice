package com.stteram.api.streams;

import java.util.ArrayList;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;



public class StreamPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*List<Integer> values=Arrays.asList(3,4,5,7);
		
		Long s=values.stream().count();
		// count() method number of elements available in list
		
		System.out.println(s);
		
		// i want to print square of every number
		
	List<Integer> square=	values.stream().map(i->i*i).toList();
	
	System.out.println(square);
	
	// i want sum of the given list
	// 1st way
	Integer sum=values.stream().map(x->x).reduce(0,(a,x)->a+x);
	
		System.out.println(sum);
		
		// 2nd way
		
		int sum2=values.stream().mapToInt(Integer::intValue).sum();
		System.out.println(sum2);
		
	List<Integer> x=Arrays.asList(45,67,8,5);
int second=	x.stream().mapToInt(Integer::intValue).sum();
System.out.println(second);
	*/

		List<Employee> l1=new ArrayList<>();
		
		l1.add(new Employee(7, "raja", "financial", 50000, 12-1-2019, 34));
		l1.add(new Employee(3, "rani", "technician", 67000, 29-5-2020, 40));
		l1.add(new Employee(9, "sita", "developer", 90000, 13-4-2019, 30));
		l1.add(new Employee(12, "rama", "testing", 20000, 17-12-2020, 24));
		l1.add(new Employee(23 ,"geeta", "devops", 300000, 12-1-2021, 14));
		l1.add(new Employee(2, "chaitu", "financial", 900000, 12-4-2019, 27));
		l1.add(new Employee(8, "himavanth", "devops", 430000, 12-8-2018, 29));
		l1.add(new Employee(6, "preeti", "developer", 50000, 12-4-2010, 42));
		l1.add(new Employee(1, "srinivas", "financial", 550000, 30-1-2020, 22));
		l1.add(new Employee(5, "pradeep", "ABC", 590000, 5-5-2021, 28));
		l1.add(new Employee(11, "yash", "developer", 50000, 16-8-2024, 56));
		
		System.out.println(l1);
		System.out.println();
	// the above code refers what am creating collection object and storing employee data	
		
//// req  i want all enames 
		
		List<String> allNames=l1.stream().map(x->x.geteName()).toList();
		System.out.println(allNames);
		
		
		// count()

		// total no of records available in the table
		
		long c=l1.stream().count();
		System.out.println("no of records in "+c);
		
	//i want all employee names who's salary>50000	
		
		List<Employee> sal=l1.stream().filter(emp->emp.getSalary()>50000).toList();
		System.out.println(sal);
		
		//// req i want first 4 employees 
		
	l1.stream().limit(4).forEach(System.out::println);
	System.out.println("************************************");
	
	// i wanr except first 4
	
	
	l1.stream().skip(4).forEach(System.out::println);
	
	
	//anyMatch() is a terminal operation  its take internal as a predicate and retuern type boolean
		// i want  employeeid >10 if condition true output true else false 
		//becoz return type is  boolean
	
	 boolean b1=l1.stream().anyMatch(emp->emp.getEid()>10);
	 System.out.println(b1);
	 
	 boolean b2=l1.stream().allMatch(emp->emp.getEid()>10);
	 System.out.println(b2);
	 
	 boolean b3=l1.stream().noneMatch(emp->emp.getEid()>10);
	 System.out.println(b2);
	 
	 // sorting 
	 
	 
	List<String> emp1= l1.stream().map(emp->emp.geteName())
	 .sorted().collect(Collectors.toList());
	
	System.out.println(emp1);
	
	
	// based on age 
	List<Employee> emp2= l1.stream().sorted((g,h)->g.getAge()-h.getAge()).toList();
			 
			
			System.out.println(emp2);
			System.out.println("**********************");
		// compare(int obj1,int obj2) but we are sorting based on String 
			// thats y showing compile time error
			
        /* List<Employee> emp3= l1.stream()
        		 .sorted((g,h)->h.geteName()-g.geteName())
        		 .toList(); */
			
			List<Employee> emp3= l1.stream()
					.sorted((g,h)->h.geteName().compareTo(g.geteName()))
					.toList();
			 
			
			System.out.println(emp3);
			
			System.out.println("#############################3333");
			
	/*List<Integer> rod=Arrays.asList(56,78,9,5,4,333,678,45);
	// default
	List<Integer> sor1=rod.stream().sorted().toList();
	System.out.println(sor1);
	
	// custom 
	List<Integer> sor2=rod.stream().sorted((y1,y2)->y2.intValue()-y1.intValue()).toList();
	System.out.println(sor2); 
	
	// min value
      Integer min1=rod.stream()
    		  .min((y3,y4)->y3.intValue()-y4.intValue()).get();
      System.out.println("Your min value is::"+min1);
	
      Integer max1=rod.stream()
    		  .max((y3,y4)->y3.intValue()-y4.intValue()).get();
      System.out.println("Your min value is::"+max1); */
			
			
			// // findAny() :: this method refers  in a fruit basekt 10 mangoos are available
			// i want pick any one of them out of 10 mangoos
	
	  
			Employee e1= l1.stream().filter(e11->e11.getSalary()>100000).findAny().get();
			System.out.println(e1);
			
			
		// i want min salary
			
		Employee min=	l1.stream().min((l11,l12)->l11.getSalary()-l12.getSalary()).get();
			
		System.out.println(min);
		
		
		// avg sala
			double avg=	l1.stream().mapToInt(x->x.getSalary()).average().getAsDouble();
		System.out.println(avg);
		
		//collectors class 
		
		
	long de=	l1.stream().filter(w1->w1.getDepartname().equalsIgnoreCase("financial"))
		.count();
	
	System.out.println(de);
	
			DoubleSummaryStatistics deptsal=		l1.stream()
					.collect(Collectors.summarizingDouble(Employee::getAge));
		System.out.println(deptsal);
	
		// grouping 
		
		
		
	Set<String> s1=	 l1.stream().map(er->er.getDepartname()).collect(Collectors.toSet());
		
	 System.out.println(s1);
	 
	 
	 //// i want get financial depeatment total salary
	 
	Map<String, Integer> ki= l1.stream().filter(s->s.getDepartname().equalsIgnoreCase("financiAL"))
	 .collect(Collectors.groupingBy(Employee::getDepartname,Collectors.summingInt(Employee::getSalary)));
	 
	 
	 System.out.println(ki);
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	}

}


class Employee
{
	 
	 private int eid;
	 private String eName;
	 private String departname;
	 private int salary;
	 private int joingDate;
	 private int age;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public String getDepartname() {
		return departname;
	}
	public void setDepartname(String departname) {
		this.departname = departname;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getJoingDate() {
		return joingDate;
	}
	public void setJoingDate(int joingDate) {
		this.joingDate = joingDate;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Employee(int eid, String eName, String departname, int salary, int joingDate, int age) {
		super();
		this.eid = eid;
		this.eName = eName;
		this.departname = departname;
		this.salary = salary;
		this.joingDate = joingDate;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", eName=" + eName + ", departname=" + departname + ", salary=" + salary
				+ ", joingDate=" + joingDate + ", age=" + age + "]";
	}
	 
	 
	
}


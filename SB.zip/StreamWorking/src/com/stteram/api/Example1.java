package com.stteram.api;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

public class Example1 {

	public static void main(String[] args) {

		LocalDate now = LocalDate.now();
        
        // Get day, month, and year
        int dayOfMonth = now.getDayOfMonth();
        String month = now.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
        int year = now.getYear();
        
        // Get the day with the appropriate ordinal suffix
        String dayWithSuffix = getDayWithOrdinal(dayOfMonth);
        
        // Print the formatted date
        System.out.println(dayWithSuffix + " " + month + " " + year);
	}

	private static String getDayWithOrdinal(int day) {
		// TODO Auto-generated method stub
		if (day >= 11 && day <= 13) {
            return day + "th";
        }
        switch (day % 10) {
            case 1: return day + "st";
            case 2: return day + "nd";
            case 3: return day + "rd";
            default: return day + "th";
        }
       
	}
}

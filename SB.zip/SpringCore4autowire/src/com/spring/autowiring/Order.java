package com.spring.autowiring;

public class Order {
	
	
	private int oid;
	private Product product1;
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public Product getProduct1() {
		return product1;
	}
	public void setProduct1(Product product1) {
		this.product1 = product1;
	}
	public Order(int oid, Product product1) {
		super();
		this.oid = oid;
		this.product1 = product1;
	}
	

}

package com.spring.beanwiring;

public class Order {
	
	
	private int oid;
	private Product productDetails;
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public Product getProductDetails() {
		return productDetails;
	}
	public void setProductDetails(Product productDetails) {
		this.productDetails = productDetails;
	}
	
	

}

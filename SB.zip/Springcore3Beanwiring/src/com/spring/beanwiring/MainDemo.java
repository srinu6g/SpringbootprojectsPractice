package com.spring.beanwiring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BeanFactory factory=new FileSystemXmlApplicationContext("C:\\Users\\91891\\eclipse-workspace\\Basics\\bin\\Springcore3Beanwiring\\beans.xml");
		Product p1=(Product)factory.getBean("product1");
		
		System.out.println("**Product details ******");
		System.out.println(p1.getPid());
		System.out.println(p1.getpName());
		System.out.println(p1.getPrice());
		
       Order o1=(Order)factory.getBean("order1");
		
		System.out.println("**order  details ******");
		System.out.println(o1.getOid());
		System.out.println(" your first order is :: " +o1.getProductDetails());
		
		 Order o2=(Order)factory.getBean("order2");
			
			System.out.println("**order  details ******");
			System.out.println(o2.getOid());
			System.out.println(" your second  order is :: " +o2.getProductDetails());
			
		
		
		
	}

}

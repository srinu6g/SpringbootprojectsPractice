package com.demo.dateandtime;

import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.LongAccumulator;

public class DateAndTimePractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * //LocalDate
		 * 
		 * 
		 * // create local date LocalDate today=LocalDate.now();
		 * System.out.println(today);
		 * 
		 * // create specific date
		 * 
		 * LocalDate specificDate=LocalDate.of(1999,06, 22);
		 * System.out.println(specificDate);
		 * 
		 * // calaculate tomorrow
		 * 
		 * LocalDate tomorrow=today.plusDays(1); System.out.println(tomorrow);
		 * 
		 * // yesterday LocalDate yesteday=today.minusWeeks(1);
		 * System.out.println(yesteday);
		 * 
		 * // for example my birthday minus one week
		 * 
		 * LocalDate birtday=specificDate.minusWeeks(1); System.out.println(birtday);
		 * 
		 * //LocalTime
		 * 
		 * // present time
		 * 
		 * LocalTime now=LocalTime.now(); System.out.println(now);
		 * 
		 * //specific time
		 * 
		 * LocalTime specificTime=LocalTime.of(5, 34,17);
		 * System.out.println(specificTime);
		 * 
		 * //plus(), minus()
		 * 
		 * LocalTime tomorrowTime=now.plusHours(6); System.out.println(tomorrowTime);
		 */
		
		
		/*S*/
		/*
		 * DateTimeFormatter
		 * formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		 * 
		 * // Format LocalDateTime to String LocalDateTime now = LocalDateTime.now();
		 * String formattedDate = now.format(formatter);
		 * System.out.println("Formatted Date-Time: " + formattedDate);
		 * 
		 * // Parse String to LocalDateTime String dateString = "2025-02-16 14:30:00";
		 * LocalDateTime parsedDate = LocalDateTime.parse(dateString, formatter);
		 * System.out.println("Parsed Date-Time: " + parsedDate);
		 * 
		 * 
		 */
        
        //
      
        
        
        LocalDateTime today=LocalDateTime.now();
        System.out.println(today);
        
        LocalDateTime tomo=LocalDateTime.now();
        
        System.out.println(tomo);
        
        
        LocalDateTime ld=LocalDateTime.ofEpochSecond(23, 4, ZoneOffset.MAX);
        
        System.out.println(ld);

        
        
	}

}

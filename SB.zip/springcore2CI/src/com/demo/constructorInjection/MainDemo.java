package com.demo.constructorInjection;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class MainDemo{
	
	public static void main(String [] args)
	{
		BeanFactory factory =new FileSystemXmlApplicationContext("C:\\Users\\91891\\eclipse-workspace\\Basics\\bin\\springcore2CI\\beans.xml");
		
		Product p2=(Product)factory.getBean("prod2");
		System.out.println(p2);
		System.out.println(p2.getPid());
		System.out.println(p2.getpName());
		System.out.println(p2.getPrice());
		
		
		
		
	}

} 

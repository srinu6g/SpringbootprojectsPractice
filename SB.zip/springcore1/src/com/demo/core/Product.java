package com.demo.core;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Product {
	
	private int pid;
	private String pName;
	private int noOfItems;
	// above all primitive datatypes
	// now we are focusing List,set,map
	private List <String> items;
	private Map<String ,Integer> pBrandPrice;
	private Set<Double> cost;
	
	
	
	
	public Map<String, Integer> getpBrandPrice() {
		return pBrandPrice;
	}
	public void setpBrandPrice(Map<String, Integer> pBrandPrice) {
		this.pBrandPrice = pBrandPrice;
	}
	public Set<Double> getCost() {
		return cost;
	}
	public void setCost(Set<Double> cost) {
		this.cost = cost;
	}
	public List<String> getItems() {
		return items;
	}
	public void setItems(List<String> items) {
		this.items = items;
	}
	private double price;
	
		public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public int getNoOfItems() {
		return noOfItems;
	}
	public void setNoOfItems(int noOfItems) {
		this.noOfItems = noOfItems;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	

}

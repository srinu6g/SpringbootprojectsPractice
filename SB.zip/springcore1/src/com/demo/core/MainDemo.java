package com.demo.core;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	BeanFactory factory=new FileSystemXmlApplicationContext("C:\\Users\\91891\\eclipse-workspace\\Basics\\bin\\springcore1\\beans.xml");
	
	Product p1= (Product)factory.getBean("prod1");
	System.out.println(p1);
	System.out.println("********Product1 details *************");
	
	System.out.println(p1.getPid());
	System.out.println(p1.getNoOfItems());
	System.out.println(p1.getpName());
	System.out.println(p1.getPrice());
		List<String>l1= p1.getItems();
	System.out.println(l1);
	
	Set<Double> s1=p1.getCost();
	System.out.println(s1);
	
	Map<String,Integer> m1=p1.getpBrandPrice();
	System.out.println(m1);
	
	
	
	
	
	

	}

}

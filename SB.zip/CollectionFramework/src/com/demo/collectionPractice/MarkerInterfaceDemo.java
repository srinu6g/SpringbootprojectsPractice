
package com.demo.collectionPractice;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MarkerInterfaceDemo implements Runnable{
	
	public void run()
	{
		System.out.println("asdfgh");
	}
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Thread t=new Thread();
		t.start();
		t.run();
		
		MarkerInterfaceDemo md=new MarkerInterfaceDemo();
		//md.start();
		md.run();
		
		
		List<String> l=Arrays.asList("rama","sfdg","qwert","fds","santoor");
	long g=	l.stream()
			
			.limit(4)
		
			.count();
			
	System.out.println(g);
	
	// i want calculate each word of a given string
	
			Map<String,Integer> mg=	l.stream()
				.collect(Collectors.toMap(word->word,word->word.length()));
	System.out.println(mg);
	
	//Convert a list of strings to uppercase using Java Streams.
	 List<String> words = Arrays.asList("hello", "world", "java", "streams","spring");
	 
	 words.stream()
	 .map(x->x.toString())
	 .forEach(System.out::println);
	//Sort a list of strings in alphabetical order using Streams.

	 System.out.println("^^^^^^^^^^^^^^^^^^^6666666666");
	 	words.stream()
	 	.sorted(Comparator.comparing(String::length).thenComparing(x->x))
	 	.forEach(System.out::println);
	 	
		
	

	}

}





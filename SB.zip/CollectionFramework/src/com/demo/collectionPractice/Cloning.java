package com.demo.collectionPractice;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Cloning  {

	public static void main(String[] args) throws CloneNotSupportedException, IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
		Student s1=new Student();
		s1.setSid(102);
		s1.setSname("ramatao");
		s1.getStudent();
		
		Student s2= (Student)s1.clone();
		s2.getStudent();
		
		
		
		
		// pattern Example Shape 1:

		
	
	 
	 // serilization 
	 
	 FileOutputStream fos=new FileOutputStream("C:\\Users\\91891\\Downloads\\Srinu_Projects\\plain.txt");
	 ObjectOutputStream oos=new ObjectOutputStream(fos);
	 oos.writeObject(s2);
	 
	oos.close();
	 
	 
	 //Deserilizable
	 
	 FileInputStream fis=new FileInputStream("C:\\Users\\91891\\Downloads\\Srinu_Projects\\plain.txt");
	 
	 ObjectInputStream ois=new ObjectInputStream(fis);
	 Student sd=(Student) ois.readObject();
	 sd.getStudent();
	 
	 ois.close();
	 
	 
	 
	 
	 
}

	

}

 class Student implements Cloneable,Serializable
 {
	 private int sid;
	 private String sname;
	 
	 public void getStudent()
	 {
		 System.out.println(sid+" :"+sname);
	 }

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

	 
	
	 
 }



package com.demo.collectionPractice;

import java.util.UUID;

public class ImmutableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Testing
		
		Address address=new Address("guntur");
		
		Employee e1=new Employee("srinivas", 25, address);
		
		System.out.println(e1.getAge());
		System.out.println(e1.getAddress().getCity());
		
		address = new Address("Managalgiri");
		
		System.out.println(e1.getAddress().getCity());
		
		
		//System.out.println(address.getCity());
		
//String
		address = new Address("ongole");
		
		System.out.println(e1.getAddress().getCity());
	// String 
		
		String s1=new String("dada");
		 System.out.println(s1);
	s1.concat("ramaraj");
		 System.out.println(s1);
		 
		 
		//Wraper class 
		 
		 Integer i1=new Integer(45);
		 System.out.println(i1);
		 Integer j=i1;
		 
		i1=i1+56;
		 System.out.println(i1);
		System.out.println(j);
		
		// UUID
		
		
		UUID uuid=UUID.randomUUID();
		System.out.println(uuid);
		
		uuid=UUID.randomUUID();
		
		System.out.println(uuid);
		
		
		Integer i=345;

		Integer j1=i;
		
		System.out.println(i);
		System.out.println(j1);
		
		
	// String
		
		String s4=new String("rama");
		System.out.println(s4);
		
		s4.toLowerCase();
		System.out.println(s4);
		
		System.out.println(s4.toLowerCase()+" add");
		
		s4.concat("door");
		System.out.println(s1);
		
		
		// wrapper
		
		Integer io=new Integer(123);
		System.out.println(io);
		  Integer rj=io;
		io=io+34;
		System.out.println(io);
		System.out.println(rj);
		
		
		
		// 
		
		UUID ransdfg= UUID.randomUUID();
		
		System.err.println(ransdfg);
		
		
		
		Address add=new Address("Vizag");
		
		
		Employee df=new Employee("sd",3, add);
		System.out.println(df.getAddress().getCity());
		
		add=new Address("ramapuram");
		
		System.out.println(df.getAddress().getCity());
		
		
		// 
		
		Integer g=new Integer(45);
		
		g=g+45;
		Integer h=g;
		System.out.println(g);
		System.out.println(h);
		
		// 
		
		A a1=new A(56);
		
		
		
		B b1=new B(89,97, a1);
		System.out.println(b1.getA().age);
		a1=new A(67);
		System.out.println(b1.getA().age);
		
		
	
		
		
		
		
		
		
	}

}
class Address
{
	private String city;

	public Address(String city) {
		//super();
		this.city = city;
	}

	public String getCity() {
		return city;
	}
	
	
	
	
	
}

 final class Employee
{
	 private  final String name;
	 private final int age;
	 private  final Address address;
	public Employee(String name, int age, Address address) {
		super();
		this.name = name;
		this.age = age;
		this.address = address;
	}
	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}
	
	public Address getAddress() {
		return address;
	}
	
	
}
 
 class A
 {
	 int age;

	public A(int age) {
		super();
		this.age = age;
	}
	 
	 
 }
 
  final class B
 {
	private final int sub1;
	private final int sub2;
	final A a;
	public B(int sub1, int sub2, A a) {
		super();
		this.sub1 = sub1;
		this.sub2 = sub2;
		this.a = a;
	}
	public int getSub1() {
		return sub1;
	}
	
	public int getSub2() {
		return sub2;
	}
	
	public A getA() {
		return a;
	}
	
	 
	 
 }
 
 
 //




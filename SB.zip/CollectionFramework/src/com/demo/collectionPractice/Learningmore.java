package com.demo.collectionPractice;

public class Learningmore  {
	
	

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		
		System.out.println("adsdfbghnh");
		
		int n=9;
		if(n>6)
		{
			System.out.println("Even");
		}
		
		else
		{
			System.out.println("odd");
		}
		
		// serilizable 
		
		
		
		
		
	}

}





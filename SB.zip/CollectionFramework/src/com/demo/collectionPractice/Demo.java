package com.demo.collectionPractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		/*
		 * String s="01584500425"; int len=s.length();
		 * System.out.println("Length :: "+len); s=s.replaceAll("0",""); int
		 * repLen=s.length(); System.out.println("Replacelenght :: "+repLen); int
		 * res=len-repLen; System.out.println(res);
		 * 
		 * s="0".repeat(res)+s;
		 * 
		 * System.out.println(s);
		 */
		// reverse a string 
		
		List<Integer> l1=Arrays.asList(23,45,56,78,9,43,67,3);
		
		// sum of array
		
	int total=	l1.stream().mapToInt(x->x).sum();
		System.out.println(total);

		//
		
			Integer sum=	l1.stream()
								.reduce(0,Integer::sum);
	
			System.out.println(sum);
			
			
		//filter is used to check condition ang giving result as a boolean type
			
			l1.stream()
			.filter(x->x>30)
			.forEach(System.out::println);
			
			
		//
			l1.stream()
			.filter(x->x>18)
			.forEach(System.out::println);
				
			
		//map()
		System.out.println("working on map()");	
		Integer any=	l1.stream()
		.map(x->x+2)
		.skip(3)
		.findAny().get();
		
		System.out.println(any);
			
			
		Integer particular=	l1.stream()
				.map(x->x+2)
				.skip(3)
				.findFirst()
				.get();	
		System.out.println(particular);
		
		
			
			
			
	}
}

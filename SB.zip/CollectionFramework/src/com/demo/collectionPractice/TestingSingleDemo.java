package com.demo.collectionPractice;

public class TestingSingleDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SingleDesignPatternDemo s3= SingleDesignPatternDemo.getInstance();
		System.out.println(s3.hashCode());
		
		SingleDesignPatternDemo s4= SingleDesignPatternDemo.getInstance();
		System.out.println(s4.hashCode());
	
		
		
	}

}

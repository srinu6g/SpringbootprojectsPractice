package com.demo.collectionPractice;

import java.util.Optional;

public class User {

	/*
	 * 
	 * public String getUserId(int id) { if(id==100) { return "raja";
	 * 
	 * } else if(id==101) { return "rani"; } else return null; }
	 * 
	 * 
	 * public Optional<String> getUserName(int id) { String name=null; if(id==100) {
	 * return Optional.ofNullable("raja");
	 * 
	 * } else if(id==101) { return Optional.ofNullable("Rani"); } else return
	 * Optional.ofNullable(name);
	 * 
	 * }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * public Optional<String> getUserInfo(int id) { //String name; if(id == 100) {
	 * return Optional.ofNullable("rana"); } else if(id == 101) { return
	 * Optional.ofNullable("rani"); } else return Optional.ofNullable(null);
	 * 
	 * 
	 * 
	 * 
	 * }
	 */
	
	public Optional<String> getUserId(int id)
	{
		String name=null;
		if(id==100)
		{
			return Optional.ofNullable("Raja");
			
		}
		else if(id==200)
		{
			return Optional.ofNullable("Rani");
		}
		else
			
		return Optional.ofNullable(name);
	}
	
	
	

}

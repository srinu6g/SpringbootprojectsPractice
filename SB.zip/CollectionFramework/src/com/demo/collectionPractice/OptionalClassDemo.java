package com.demo.collectionPractice;

import java.util.Optional;
import java.util.Scanner;

public class OptionalClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * // create object
		 * 
		 * Scanner sc=new Scanner(System.in);
		 * 
		 * System.out.println("Enter id"); int id=sc.nextInt();
		 * 
		 * User user=new User(); String info= user.getUserId(id);
		 * 
		 * if(info!=null) { String res=info.toUpperCase()+ " " +"hello";
		 * 
		 * System.out.println(res); } else System.out.println("Not found");
		 * 
		 * 
		 * 
		 * }
		 * 
		 * // but every time programmer may check or maynot check if null is handles or
		 * not // to avoid above problem //optional class coming to the picture
		 * 
		 * Optional<String> res= user.getUserName(id);
		 * 
		 * if(res.isPresent()) { String pour=res.get(); String
		 * de=pour.toUpperCase()+" hello"; System.out.println(de); } else
		 * System.out.println("not found");
		 * 
		 * 
		 * }
		 * 
		 * 
		 * 
		 * Optional<String> res =user.getUserInfo(id);
		 * 
		 * System.out.println(res);
		 */
		
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id");
		int id=sc.nextInt();
		
		User user=new User();
		Optional<String> res=user.getUserId(id);
		
		System.out.println(res);
		
		
		
		
		
		
		

	}
}

package com.demo.collectionPractice;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class HashMapDemo {

	public static void main(String[] args) {
		
		
		/*
		 * Hashtable h=new Hashtable<>();
		 * 
		 * h.put(new Temp(5),'A'); h.put(new Temp(2),'B');
		 * 
		 * //h.put(new Temp(6),'C'); h.put(new Temp(15),'D');
		 * 
		 * h.put(new Temp(23),'E'); h.put(new Temp(16),'F');
		 * 
		 * System.out.println(h);
		 */
		
	// how to convert synchronized hasmpap
		
		
			Map<Integer,String> m=	Collections.synchronizedMap(new HashMap<>());
	
			m.put(1, "one");
			m.put(11, "eleven");
			
			m.put(8, "eight");
			
			m.put(9, "nine");
			m.put(6, "six");
			m.put(20, "twenty");
			m.put(82, "eightytwo");
			
			System.out.println(m);
		
			  // Synchronized block required for iteration
	        synchronized (m) {
	            for (Map.Entry<Integer, String> entry : m.entrySet()) {
	                System.out.println(entry.getKey() + " -> " + entry.getValue());
	            }
	        }
	        
	        ConcurrentHashMap<Integer, String> concurrentHashMap=new ConcurrentHashMap<>();
	        concurrentHashMap.put(1, "Apple");
	        concurrentHashMap.put(2, "Banan");
	        concurrentHashMap.put(3, "Tomato");
	        concurrentHashMap.put(4, "Potato");
	        
		
		System.out.println(concurrentHashMap);
		
		concurrentHashMap.put(2, "Banana");
		System.out.println(concurrentHashMap);
		
		
		
		
		
		
		
		String name="srinivas";
		
		name="srinivas rao";
		System.out.println(name);
		
		
		//01405600802 i/p
		//14568200000 o/p
		
			
		

	}

}


class Temp
{
	int i;

	public Temp(int i) {
		super();
		this.i = i;
	}

	@Override
	public int hashCode() {
		return i;
	}

	@Override
	public String toString() {
		return " " + i + " ";
	}

	
}

package com.demo.collectionPractice;

public class SingleDesignPatternDemo {
	
	// global object declaration
	//static SingleDesignPatternDemo s1=new SingleDesignPatternDemo();// eage inti
	
	static SingleDesignPatternDemo s1=null; // lazy initilization
	private SingleDesignPatternDemo() {
		// super();
		// TODO Auto-generated constructor stub
	}
	
	public static SingleDesignPatternDemo getInstance()
	{
		if(s1==null)
		{
		    s1= new SingleDesignPatternDemo();
		}
		return s1;
		
	}

}

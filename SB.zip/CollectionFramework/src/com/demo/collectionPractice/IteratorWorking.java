package com.demo.collectionPractice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class IteratorWorking {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Integer> a=new ArrayList<>();
		a.add(23);
		a.add(34);
		a.add(9);
		
		
		a.add(89);	
		a.add(342);	
		
		System.out.println(a);
		
		System.out.println("Forward");
		Iterator i=a.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}
		// backwrd
		System.out.println("forkward");
		ListIterator litr=a.listIterator();
		while(litr.hasNext())
		{
			System.out.print(litr.next()+" ");
		}
		System.out.println();
		System.out.println("backewasd");
		while(litr.hasPrevious())
		{
			System.out.print(litr.previous()+" ");
		}
		
		
		

	}

}

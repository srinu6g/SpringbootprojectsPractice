package com.demo.collectionPractice;

import java.util.Arrays;
import java.util.List;

public class CloningDemo {

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		AddressDemo ad=new AddressDemo("medapi",534261);
		ad.getAddressDetails();
		
		AddressDemo ad2=(AddressDemo)ad.clone();
		ad2.getAddressDetails();
		AddressDemo ad3=(AddressDemo)ad2.clone();
		ad3.getAddressDetails();
		
		
		List<Integer> l1=Arrays.asList(23,4,5,6);
		
		

	}

}

class AddressDemo  implements Cloneable
{
	private String city;
	private int pincode;
	
	public void getAddressDetails()
	{
		System.out.println(city+ " "+pincode);
	}

	

	public void setCity(String city) {
		this.city = city;
	}

	public int getPincode() {
		return pincode;
	}



	public AddressDemo(String city, int pincode) {
		super();
		this.city = city;
		this.pincode = pincode;
	}



	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

	
	
	
}

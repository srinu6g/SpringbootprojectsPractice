package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.UserInformation;

@Repository
public interface UserRepository extends JpaRepository<UserInformation,String> {

	
	//i want retrive data based on city
	
	List<UserInformation> findByCity(String city);
	

	//i want retrive data based on city and age
	
	List<UserInformation> findByCityAndAge(String city,int age);

}

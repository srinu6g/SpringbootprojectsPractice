package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.UserInfo;
import com.example.demo.entity.UserInformation;
import com.example.demo.repository.UserRepository;

@Service
public class UserService {
	//autowired
	@Autowired
	UserRepository userRepository;

	public String createUserDetails(UserInfo userInfo) {
		
		Optional<UserInformation> userInfoo=   userRepository.findById(userInfo.getEmail());
		// this line what ever email coming from req/client that is checking is already availble or not
		//if availble if case executed
		String result=null;
		if(userInfoo.isPresent())
		{
			//return"emaild alredy existed please try another email: "+userInfo.getEmail();
			return result; // this response forward to controller layer
			// result null means  emaild alredy existed please try another email
		}
		//otherwise not avilable else case executed means record added /created in DB
		else
		{
			System.out.println(userInfo);
			UserInformation userInformation =new UserInformation();
			userInformation.setEmail(userInfo.getEmail());
			userInformation.setName(userInfo.getName());
			userInformation.setCity(userInfo.getCity());
			userInformation.setAge(userInfo.getAge());
			userInformation.setPassword(userInfo.getPassword());
			
			userRepository.save(userInformation);
			return "record adddede sucess in Database " ;
			
		}
		
	}
	

	// i want retrive data based on city

	public List<UserInformation> gettingDetailsOncity(String city) {
		// TODO Auto-generated method stub
		
		return userRepository.findByCity(city);
		
		
		
	}


	public List<UserInformation> gettingDetailsOncityAndAge(String city, int age) {
		// TODO Auto-generated method stub
		return userRepository.findByCityAndAge(city,age);
	}
	
	
	
	

}

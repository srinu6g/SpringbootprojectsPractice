package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.UserInfo;
import com.example.demo.entity.UserInformation;
import com.example.demo.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	UserService userService;
	
	//DB level record crested :: 201 created succes
	//200 Ok emailId alredy exist please try another email server send respone to client
	//in these client and server both are excuted successfully 
	//but you(server) are inform to client ass meaning full response to client
	
	
	@GetMapping(path = "/create/user",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> createUser(@RequestBody UserInfo userInfo)
	{
		System.out.println("User Information is here :"+userInfo);
		
		//TODO forard service layer
		
		String res=userService.createUserDetails(userInfo);
		//ResponseEntity<String> entity=new ResponseEntity<String>(null, null);
		
		// res is coming from service layer 
		//check if null or not null 
		// if null 200 0k 
		// notNull 201 created
		if(res!=null)
		{
			// 201 created 
			// service claass else block excuted
			
			return new ResponseEntity<String>(res,HttpStatusCode.valueOf(201));
		}
		else
		{
			// 200 ok 
			//emaild alredy existed please try another email
			return new ResponseEntity<String>("emaild alredy existed please try another email",HttpStatus.OK);
		}
		//HttpStatuscodes we can pass with the help of ResponseEntity class
		//this class bind the actual response+ current reponse
		//
		
		
	}
	/* Http status codes when ever sending first time that emailid not avialable in database
	 * level data will be inserted /created successfully that time actually showing 
	 * the http status code is 200 Ok but is it really 200 0k status code : no
	 * inplace of that i want 201 created succes 
	 * then second and third time am sending req , excution done getting 200 Ok but records not addded in my 
	 * DB level becaoz already emaild id existed same email so that time server giving response to client asa meaningful status code or not 
	 * that time 200 0k with ::  emailId alredy exist please try another email
	 * 
	 * the above problem how to solve by using" ResponseEntity class"
	 * 
	 * 
	 */
	
	
	
	
	
	
	
	
	
	
	
	
	
	// i want retrive data based on city
	
	
	@GetMapping("/getting/user/{cityName}")
	public List<UserInformation>  getUserDetailsBaseOncity(@PathVariable("cityName") String city)
	{
		
	       return userService.gettingDetailsOncity(city);
		
	}
	
	//localhost:7777/flipkart/getting/user/HYD
	
	// based on city and age
	
	@GetMapping("/more/user/{cityName}")
	public List<UserInformation>  getUserDetailsBaseOncityAndAge(@PathVariable("cityName") String city,@RequestParam("age") int age)
	{
		
	       return userService.gettingDetailsOncityAndAge(city,age);
		
	}
	
	
	//localhost:7777/flipkart/more/user/HYD?age=25
	
	
	

}

package com.example.demo.jwt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JWtController {
	
	/*
	 * // autowiring
	 * 
	 * @Autowired JwtTokenManager jwtTokenManager;
	 * 
	 * 
	 * @RequestMapping("/say/hello") public String sayHello() { return
	 * "how are you"; }
	 * 
	 * 
	 * // first we loginn with userId
	 * 
	 * @PostMapping("/create/token/{userId}") public String
	 * createToken(@PathVariable("userId") String loginUserId ) { return
	 * jwtTokenManager.createToken(loginUserId); }
	 * 
	 * @PostMapping("/validate/token/{userIdname}") public boolean
	 * validateToken(@PathVariable("userIdname") String
	 * loginUserId,@RequestHeader("token") String token) { return
	 * jwtTokenManager.isValidToken(loginUserId,token); }
	 */
	
	
	// creation of token
	
	@Autowired
	JwtTokenManager jwtTokenManager;
	
	@GetMapping("/create/token/{userId}")
	public String createTokenExplain(@PathVariable ("userId") String userId)
	{
	String res=	jwtTokenManager.createUser(userId);
		return res;
	}
	// genereated userID:: amma@gmail.com
	/* token::
	 * eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbW1hQGdtYWlsLmNvb
	 * SIsImlhdCI6MTczNjE0ODcwNiwiZXhwIjoxNzM2MTQ5MDA2fQ.
	 * 2Wk0dYzcVN2udIXToeYJLw_dE8clQ8568ZVDhBDYtdg
	 */

	/*
	 * abc123 :: userId
	 * token ::eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhYmMxMjMiLCJpYXQiOjE3MzYxNDg3NzAsImV4cCI6
	 * MTczNjE0OTA3MH0.Aej-BzjZ9aORJijRw1dSg0BfSHZqnjjpALy28u6RTTI
	 */
}

/*
 * 
 * userId :abc123
 * 
 * 
 * token
 * eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhYmMxMjMiLCJpYXQiO
 * jE3MzM3NDExOTQsImV4cCI6MTczMzc0MTQ5NH0.89E1a1qX0nBPIDsXN0DB
 * ZlhUx63zPiQuL_4vJIZyXPU
 * 
 * 
 * 
 * 
 * 
 * userId: amma123
 * tolekn:eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbW1hMTIzIiwiaWF0IjoxNzM5ODQ4MjU4LCJleHAiOjE3Mzk4NDg1NTh9.vjtQQIzPbKjQB-d8QB06nhDvRhmYZBRfOxClGu9uJlg
 * 
 * 
 * 
 * 
 */

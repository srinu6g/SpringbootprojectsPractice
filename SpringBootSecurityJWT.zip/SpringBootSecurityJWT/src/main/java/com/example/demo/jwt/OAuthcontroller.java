package com.example.demo.jwt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OAuthcontroller {
	
	@Autowired
	JwtTokenManager jwtTokenManager;
	
	
	// create token 
	
	
	@PostMapping("/demo/oauth")
	public String createToken(@RequestParam ("userId") String userId)
	{
		
		//jwtTokenManager.createUser(userId);
		return jwtTokenManager.createUser(userId);

	}
	
	

}

package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.UserRepository;
import com.example.demo.dto.UserDetails;
import com.example.demo.entity.User;

@Service
public class UserService {
	
	@Autowired
	UserRepository userRepository;

	public String createUser(UserDetails userDetails) {
		// TODO Auto-generated method stub
		
		
		//System.out.println(userDetails);
		
		
		//TODO  forward repository
		
		User user =new User();
		user.setEmail(userDetails.getEmail());
		user.setName(userDetails.getName());
		user.setGender(userDetails.getGender());
		user.setContact(userDetails.getContact());
		user.setCity(userDetails.getCity());
		
		userRepository.save(user);
		
		
		
		return "user created succesfull";
		
	}

	public List<User> gettingDetailsOnGender(String gender) {
		// TODO Auto-generated method stub
		
	  List<User> users=userRepository.findByGender(gender);
	
		return users;
	}
//  yor task is i want retive data from database based on gender and City
	

	public List<User> gettingDetailsOnGenderAndCity(String gender, String city) {
		// TODO Auto-generated method stub
		
		//userRepository.findByGenderAndCity(gender, city);
		
		return  userRepository.findByGenderAndCity(gender, city);
	}
	
	public List<String> gettingBasedOnNames(String name)
	{
		return userRepository.allNames(name);
	}

	public User gettingInfoBasedOnEmail(String email) {
		// TODO Auto-generated method stub
		
		// 
		
		User user=userRepository.findById(email).get();
		
		
		return user;
		
		
	}
	
	
	

}

package com.example.demo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.BankUser;

@RestController
public class BankController {
	
	
	
	// now am trying to explain  loggers 
	// at whAT TIME 	bank employee login in website at what time logout so this kind of 
	// business logics you have to write in real time projects using  " Loggers"
	
	// create logger object
	
	Logger logger=LoggerFactory.getLogger(BankController.class);
	@PostMapping("/user/bank")
	 public String UserDetails(@RequestBody BankUser bankUser)
	 {
		// System.out.println("your details "+bankUser);
		logger.info("your details "+bankUser);
		logger.info(" your registred as "+bankUser.getEmail() +":: this email id");
		logger.error(" your registred as "+bankUser.getEmail() +":: this email id");
		logger.warn(" your registred as "+bankUser.getEmail() +":: this email id");
		logger.debug(" your registred as "+bankUser.getEmail() +":: this email id");
		logger.trace(" your registred as "+bankUser.getEmail() +":: this email id");
		// by default enable logger.info()  by springboot 
		// that's why debug,trace are not executed
		// but when am exuted info() it will execute error,warn also
		// TRACE <-DEBUG <- INFO <- WARN <-- ERROR
		// this flow is executed 
		//if you are enable trace all loggera will be excuted
		// if  debug enable all are excuted expect trace
		// how to enable debug simply add properties file regarding debug
		
		
		 return "user created";
		 
	 }
	
	

}

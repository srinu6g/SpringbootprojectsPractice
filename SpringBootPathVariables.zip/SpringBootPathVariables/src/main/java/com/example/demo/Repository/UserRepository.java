package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.entity.User;


public interface UserRepository extends JpaRepository<User,String> {
	
	
// i want retrive data based on Gender
	
	public List<User>  findByGender(String gender);
	
//  yor task is i want retive data from database based on gender and City
	
	List<User>  findByGenderAndCity(String gender,String city);
	
	// i want retrive all employee names
	
	@Query(value = "select name from preeti",nativeQuery = true)
	List<String> allNames(String name);
}

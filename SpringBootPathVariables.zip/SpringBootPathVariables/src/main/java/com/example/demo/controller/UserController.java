package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.UserDetails;
import com.example.demo.entity.User;
import com.example.demo.service.UserService;

import jakarta.validation.Valid;

@RestController
public class UserController {
	
	// injecting service class
	@Autowired
	UserService  userService;
	
	
	
	
	
	//  we can define n no of rest services inside a controller class
	
	
	
	
	/*
	 * @RequestMapping(path = "/create/user/account",method =
	 * RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	 * 
	 * public String createUserDetails(@RequestBody UserDetails
	 * userDetails,@RequestHeader("actor") String actorName) {
	 * System.out.println("your userdetails are "+userDetails);
	 * System.out.println("your actor acting as :"+actorName);
	 * 
	 * return "creted success";
	 * 
	 * }
	 * 
	 * 
	 * // the above is how to pass header // i exchane infomartion from client to
	 * server // header concept is a global concept where " http procol" thta oplace
	 * /that time header concept is ther // it is not relTED TO SPRING/SPRINGBOOT
	 * 
	 * //***************** how to getting response from server via header
	 ********/
	/*
	 * @RequestMapping(path = "/create/user/account/getting",method =
	 * RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE) public
	 * ResponseEntity<String> createUser(@RequestBody UserDetails
	 * userDetails,@RequestHeader("actor") String actorName) {
	 * System.out.println("your userdetails are "+userDetails);
	 * System.out.println("your actor acting as :"+actorName);
	 */
	  
	 /* // getting response from server in springFW provide a class called
	 // " HttpHeaders"
*/	  
	 /* HttpHeaders response=new HttpHeaders(); response.add("Balayya", "Daaku Maharaj");
	  
	  
	  
	  
	  return new ResponseEntity<String>("user created success",
	  response,HttpStatus.OK);
	  
	  }*/


		@RequestMapping(path = "/create/user",method = RequestMethod.POST)
		public String userAccoutCreated(@RequestBody UserDetails userDetails)
		{
			System.out.println("your data is coming or not "+userDetails);
			//TODO service,Repository
			//forward service layer 
			
			String response=userService.createUser(userDetails);
			
			
	
			return response;
			
		
		}
		
		
		
		 // i want retirve data based on gender 
		
		@GetMapping("/user/data/{genderName}")
		public List<User> gettingUserInfoBasedOnGender(@PathVariable("genderName") String gender)
		{
			//TODO  service 
			
			 List<User> l1=userService.gettingDetailsOnGender(gender);
			
			
			
			return l1;
			
		}
		
		//  yor task is i want retive data from database based on gender and City
		
		/*@GetMapping("/user/data/{gender}/{city}")
		public List<User> gettingUserInfoBasedOnGenderAndCity(@PathVariable("gender") String gender,
				@PathVariable("city") String city)
		{
			//TODO  service 
			
			 List<User> l2=userService.gettingDetailsOnGenderAndCity(gender,city);
			
			
			
			return l2;
			
		}*/


// getting all names from USER table


		@GetMapping("/user/data")
		public List<String> gettingAllNames(String name)
		{
			//TODO  service 
			List<String> allNames=userService.gettingBasedOnNames(name);
			 
			return allNames;
		}




	//  yor task is i want retive data from database based on gender and City
		// gender am passing as a pathvarible 
		//city am passing as Query paramter
		
			@GetMapping("/user/{gender}")
			public List<User> gettingUserInfoBasedOnGenderAndCity(@PathVariable("gender") String gender,
					@RequestParam("city") String city)
			{
				//TODO  service 
				
				 List<User> l2=userService.gettingDetailsOnGenderAndCity(gender,city);
				
				
				
				return l2;
				
			}


          // i want to retrive data based on emaild
			
			
			@RequestMapping(path = "/userData/access",method = RequestMethod.GET)
			public User gettingDetailsBasedOnEmail(@RequestParam("email") String email)
			{
				System.out.println("your are asking :: "+email +" :: person details ");
				
				User u1=userService.gettingInfoBasedOnEmail(email);

				
				System.out.println(u1.getEmail());
				
				return u1;
			}
			
			
	//Request body validations
			
			@PostMapping("/user/validation")
			public String SayValidations (@Valid
 @RequestBody UserDetails userDetails)
			{
				System.out.println(userDetails);
				return "i am checking validations concept";
			}
	//until n ow is there any validation no
			
			


	
}

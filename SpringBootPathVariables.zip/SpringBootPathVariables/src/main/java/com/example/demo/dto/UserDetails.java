package com.example.demo.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class UserDetails {
	
	
	

	@NotBlank(message = "name must be not blank anf not null") 
	  @Size(min = 4, max = 10)// not null + not empty
	private String name;
	
	@NotBlank
	@Email
	private String email;
	private String gender;
	
	// @NotBlank ==> it is a supported for string properties
	private long contact;
	
	private String city;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "UserDetails [name=" + name + ", email=" + email + ", gender=" + gender + ", contact=" + contact
				+ ", city=" + city + "]";
	}
	

}

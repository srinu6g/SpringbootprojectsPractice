package com.bys.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VerifyOtpResponse {
    String access_token;
    String refresh_token;
    String roleName;
    String userName;
    String mobOrCfmsId;
}

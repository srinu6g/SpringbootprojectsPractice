package com.bys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookYourStayApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookYourStayApplication.class, args);
	}

}

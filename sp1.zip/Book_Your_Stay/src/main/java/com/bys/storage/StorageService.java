package ap.bhavan.storage;

import ap.bhavan.exceptions.BadRequestException;
import ap.bhavan.exceptions.FileUploadException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@RequiredArgsConstructor
@Service
public class StorageService {

    @Value("${application.bucket.name}")
    private String bucketName;

    @Value("${application.folder.name}")
    private String folderName;


    private final S3Client s3Client;


    private final Environment env;

    String msg1="File is not attached or Empty";
    String msg2="File name is invalid or missing";
    String msg3="File does not have a valid extension";

    public String uploadFile2(String fileName, File file) {
        if (file != null) {
            s3Client.putObject(PutObjectRequest.builder().bucket(bucketName).key(folderName + "/" + fileName).build(), RequestBody.fromFile(file));
            return fileName;
        } else {
            throw new FileUploadException(msg1);
        }
    }

    public String uploadFile(File f, String fileName) {
        String filename = (System.currentTimeMillis() + "_" + fileName).replaceAll("\\s", "");
        s3Client.putObject(PutObjectRequest.builder().bucket(bucketName).key(folderName + "/" + fileName).build(), RequestBody.fromFile(f));
        return filename;
    }

    public String deleteWorkFile(String fileName) {
        DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder().bucket(bucketName).key(folderName + "/" + fileName).build();
        s3Client.deleteObject(deleteObjectRequest);
        return fileName + " removed.";
    }

    public String uploadFile(MultipartFile file) throws IOException {
        if (file == null) {
            throw new IOException(msg1);
        }
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || originalFilename.isEmpty()) {
            throw new IOException(msg2);
        }
        File f = convertMultiPartFileToFile(file);
        int extensionIndex = originalFilename.lastIndexOf(".");
        if (extensionIndex == -1) {
            throw new IOException(msg3);
        }

        String attachmentFileName = originalFilename.substring(0, extensionIndex);
        String attachmentExtension = originalFilename.substring(extensionIndex);
        String filename = attachmentFileName + "_" + System.currentTimeMillis() + attachmentExtension;

        s3Client.putObject(PutObjectRequest.builder()
                        .bucket(bucketName)
                        .key(folderName + "/" + filename)
                        .build(),
                RequestBody.fromFile(f));

        return filename;
    }



    public String uploadFileToS3 (MultipartFile file, String fileType) throws IOException {
        if (file == null || file.isEmpty()) {
            throw new IOException(msg1);
        }

        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || originalFilename.isEmpty()) {
            throw new IOException(msg2);
        }

        int extensionIndex = originalFilename.lastIndexOf(".");
        if (extensionIndex == -1) {
            throw new IOException(msg3);
        }

        String attachmentExtension = originalFilename.substring(extensionIndex);


        String filename = fileType + "_" + System.currentTimeMillis() + attachmentExtension;

        File f = convertMultiPartFileToFile(file);


        s3Client.putObject(PutObjectRequest.builder()
                        .bucket(bucketName)
                        .key(folderName + "/" + filename)
                        .build(),
                RequestBody.fromFile(f));
        return filename;
    }


    private File convertMultiPartFileToFile(MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException(msg1);
        }

        String originalFilename = file.getOriginalFilename();
        String convertedFileName = System.currentTimeMillis() + "_" + originalFilename;

        File convertedFile = new File("your/directory/path/" + convertedFileName);

        try (FileOutputStream fos = new FileOutputStream(convertedFile)) {
            fos.write(file.getBytes());
        } catch (IOException e) {
            throw new IOException("Failed to convert MultipartFile to File: " + e.getMessage());
        }

        return convertedFile;
    }


    public byte[] downloadFile(String fileName, String token) throws IOException, BadRequestException {
        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.set("Authorization", token);
        headers.set("module", "apbh");

        HttpEntity<String> entity = new HttpEntity<>(headers);

        String downloadUrl = env.getProperty("dms-download-url");
        downloadUrl = downloadUrl + "apbh/download/" + fileName;
        ResponseEntity<ByteArrayResource> responseEntity = null;
        ByteArrayResource responseBody = null;
        try {
            responseEntity = restTemplate.exchange(downloadUrl,
                    HttpMethod.GET,
                    entity,
                    ByteArrayResource.class
            );
        } catch (Exception e) {
            throw new IOException("Error while downloading the file");
        }

        if (!responseEntity.getStatusCode().is2xxSuccessful()) {
            throw new BadRequestException("File not found with the given name");
        }

        responseBody = responseEntity.getBody();
        if (responseBody == null) {
            throw new BadRequestException("No content received in the response");
        }
        return responseBody.getByteArray();

    }
    private void deleteFile(String fileKey) {
        DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
                .bucket(bucketName)
                .key(fileKey)
                .build();
        s3Client.deleteObject(deleteObjectRequest);
    }

    // Public method to remove a file by its name
    public String removeFileByName(String fileName) {
        String fileKey = folderName + "/" + fileName;
        deleteFile(fileKey);  // Reuse the common logic
        return fileName + " removed.";
    }



    public File convertByteArrayToFile(byte[] byteArray, String fileName) {
        File file = new File(fileName);
        try (FileOutputStream fos = new FileOutputStream(file)) {
            fos.write(byteArray);
        } catch (Exception e) {
            throw new FileUploadException("Unable to create file from the given Byte Array");
        }
        return file;
    }


    public String uploadFileFromByteArray(byte[] byteArray, String fileName) {
        if (byteArray != null && byteArray.length != 0) {
            s3Client.putObject(PutObjectRequest.builder().bucket(bucketName).key(folderName + "/" + fileName).build(), RequestBody.fromBytes(byteArray));
            return fileName;
        } else {
            throw new FileUploadException(msg1);
        }
    }

}

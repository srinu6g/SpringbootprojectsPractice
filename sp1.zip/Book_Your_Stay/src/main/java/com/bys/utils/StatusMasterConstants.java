package com.bys.utils;

public class StatusMasterConstants {
	private StatusMasterConstants() {
		throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
	}

	public static final String SMS_TEMPID_SMS_STRIKER_OTP = "1407166237464854505";
	public static final String NUMERIC_REGEX = "^[0-9]+$";
	public static final int OTP_VALIDATION_MINUTES = 3;
	public static final String ASIA_KOLKATA = "Asia/Kolkata";

	public static final Integer APBHAVAN_STATUS_INPROGRESS_ID = 2;
	public static final Integer APBHAVAN_STATUS_RESOLVED_ID = 4;

	public static final Integer APBHAVAN_STATUS_ONHOLD_ID = 3;
	public static final Integer APBHAVAN_STATUS_CLOSED_ID = 5;
	public static final Integer APBHAVAN_STATUS_REOPENED_ID = 6;

}
package com.bys.utils;

public class DataValidations {
	private DataValidations() {
		throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
	}

	public static boolean nullValidation(String str) {
		boolean flag = true;

		if (str == null || str.isEmpty() || str.equals("") || str.trim() == null || str.trim().equals("")
				|| str.trim().equals("null") || str.trim().equals("(null)") || str.trim().equals("[NULL]")
				|| str.trim().equals("0"))
			flag = false;
		return flag;
	}
}
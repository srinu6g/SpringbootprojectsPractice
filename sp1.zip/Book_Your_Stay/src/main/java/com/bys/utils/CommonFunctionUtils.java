package com.bys.utils;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;

import javax.net.ssl.HttpsURLConnection;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.bys.exceptions.BadRequestException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import static com.bys.utils.StatusMasterConstants.ASIA_KOLKATA;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class CommonFunctionUtils {

	@Value("${sms.url}")
	private String smsHostUrl;

	private static final SecureRandom secureRandom = new SecureRandom();


	public String sendSingleSMS(String mobileNo, String message, String tempId) throws BadRequestException {
		String result = "Fail";
		try {

			message = message.replace(" ", "%20").replace("~", "%0A");
			HttpsURLConnection conn = getHttpsURLConnection(mobileNo, message, tempId);

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output=null;
			String r = "";
			while ((r = br.readLine()) != null) {
				output = r;
			}
			conn.disconnect();
			if (output != null && !output.equals("")) {
				String[] strArr = output.split(",");
				if (strArr.length > 0) {
					String[] wordRes = strArr[1].split(":");
					if (wordRes.length > 0 && wordRes[1].trim().contains("Messages has been sent")) {
						result = "Success";
					}
				}
			}
		} catch (IOException e){

			throw new BadRequestException(e.getLocalizedMessage());
		}
		return result;
	}

	public String getMapTojsonString(Map<String, Object> mapData) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.writeValueAsString(mapData);
		} catch (JsonProcessingException e) {
			return "{}";
		}
	}


	public Map<String, Object> getMapObjectwithJsonString(String data) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(data, Map.class);
	}

	private HttpsURLConnection getHttpsURLConnection(String mobileNo, String message, String tempId)
			throws IOException {
		String smsURL = smsHostUrl + mobileNo + "&msg=" + message + "&type=1&template_id=" + tempId;

		URL url = new URL(smsURL);
		HttpsURLConnection conn = null;

		conn = (HttpsURLConnection) url.openConnection();
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Accept", "application/json");

		if (conn.getResponseCode() != 200) {
			throw new IOException("Failed : HTTP error code : " + conn.getResponseCode());
		}
		return conn;
	}



	public String getDate(Timestamp date) {
		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		return localDate.format(formatter);

	}

	public String getPrincipal() {
		return SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
	}

	
	public static StringBuilder hashingMobileNumber(String mobileNumber) {
		var hashMobile = new StringBuilder(mobileNumber.substring(0, 2) + "xxxxx");
		String lastDigits = mobileNumber.substring(7, 10);
		return hashMobile.append(lastDigits);
	}

	public static String random() {
		final int numbers = 100000 + secureRandom.nextInt(900000);
		return String.valueOf(numbers);
	}
	public static Timestamp getCurrentTimeStamp()
	{
		TimeZone.setDefault(TimeZone.getTimeZone(ASIA_KOLKATA));
		Date now = new Date();
		return new Timestamp(now.getTime());
	}





}

package com.bys.utils;


import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

import com.bys.exceptions.DecryptionException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum AESUtils {
    ;

    //AES (Advanced Encryption Standard) algorithm is 128 bits, 192 bits, or 256 bits
    private static final String AES_ALGORITHM = "AES";
    // AES encryption mode is CBC and padding method is PKCS5Padding.
    private static final String AES_TRANSFORMATION = "AES/GCM/NoPadding";
    // AES key is 16 characters.
    private static final String AES_KEY = "E71FDD277741D2FC8A710ADA5DD4E5D6";
    // AES initialization vector is 16 characters.
    private static final String AES_IV = "0000000000000000";
    private static final int IV_LENGTH = 12;
    private static final int TAG_LENGTH = 128;

    public static String encrypt(String src) {
        try {
            Cipher cipher = Cipher.getInstance(AES_TRANSFORMATION);
            byte[] iv = new byte[IV_LENGTH];
            SecureRandom secureRandom = new SecureRandom();
            secureRandom.nextBytes(iv);

            GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(TAG_LENGTH, iv);

            SecretKey key = makeKey();
            cipher.init(Cipher.ENCRYPT_MODE, key, gcmParameterSpec);

            byte[] encryptedBytes = cipher.doFinal(src.getBytes(StandardCharsets.UTF_8));
            ByteBuffer byteBuffer = ByteBuffer.allocate(IV_LENGTH + encryptedBytes.length);
            byteBuffer.put(iv);
            byteBuffer.put(encryptedBytes);

            return Base64.encodeBase64String(byteBuffer.array());
        } catch (Exception e) {
            throw new DecryptionException("Error while encrypting the input", e);
        }
    }

    public static String decrypt(String src) {
        try {
            Cipher cipher = Cipher.getInstance(AES_TRANSFORMATION);

            byte[] decodedBytes = Base64.decodeBase64(src);

            ByteBuffer byteBuffer = ByteBuffer.wrap(decodedBytes);
            byte[] iv = new byte[IV_LENGTH];
            byteBuffer.get(iv);
            byte[] cipherText = new byte[byteBuffer.remaining()];
            byteBuffer.get(cipherText);

            GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(TAG_LENGTH, iv);

            SecretKey key = makeKey();
            cipher.init(Cipher.DECRYPT_MODE, key, gcmParameterSpec);

            byte[] decryptedBytes = cipher.doFinal(cipherText);
            return new String(decryptedBytes, StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new DecryptionException("Error while decrypting the input", e);
        }
    }

    private static SecretKey makeKey() {

        byte[] keyBytes = AES_KEY.getBytes(StandardCharsets.UTF_8);
        return new SecretKeySpec(keyBytes, AES_ALGORITHM);
    }


    public static GCMParameterSpec makeIv() {
        byte[] iv = AES_IV.getBytes(StandardCharsets.UTF_8);
        return new GCMParameterSpec(TAG_LENGTH, iv);
    }




}

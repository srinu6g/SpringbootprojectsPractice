package com.bys.service;

import org.springframework.stereotype.Service;

import com.bys.request.EmailRequest;

@Service
public interface EmailService {

    void sendEmail(EmailRequest emailRequest);

}


package com.bys.service;


import java.util.Map;

import org.json.JSONException;
import org.keycloak.representations.AccessTokenResponse;
import org.springframework.stereotype.Service;

import com.bys.exceptions.BadRequestException;
import com.bys.exceptions.InvalidDataException;
import com.bys.exceptions.LoginTimeoutException;
import com.bys.exceptions.ResourceNotFoundException;
import com.bys.exceptions.UnauthorizedException;
import com.bys.request.GenericOTPPayload;
import com.bys.request.OtpReqeuest;
import com.bys.request.SmsLogsEnityRequest;
import com.bys.request.UpdateRequest;
import com.bys.response.VerifyOtpResponse;
import com.bys.security.BaseResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import jakarta.servlet.http.HttpServletRequest;

@Service
public interface LoginService {

    BaseResponse<Map<String, String>> sendGenericOneTimePassword(String mobileNumber) throws ResourceNotFoundException, BadRequestException;

    VerifyOtpResponse verifyOtp(String encrptedCode, GenericOTPPayload genericOTPPayload,
                                HttpServletRequest request) throws UnauthorizedException, BadRequestException, ResourceNotFoundException, JsonProcessingException;

	BaseResponse<Map<String, String>> getTokenFromRefreshToken(String refreshToken) throws BadRequestException, LoginTimeoutException, UnauthorizedException;

    String sendOtpSms(SmsLogsEnityRequest request, HttpServletRequest req) throws ResourceNotFoundException, BadRequestException;

    String saveNewPassword(SmsLogsEnityRequest request, HttpServletRequest req) throws ResourceNotFoundException;

    Map<String,String> validateOtp(OtpReqeuest otp, HttpServletRequest req) throws InvalidDataException, ResourceNotFoundException;

    String otpGeneration(String cfmsId) throws BadRequestException;

    AccessTokenResponse updatePassword(UpdateRequest updateRequest) throws UnauthorizedException,
    JSONException, ResourceNotFoundException, JsonMappingException, JsonProcessingException;
}

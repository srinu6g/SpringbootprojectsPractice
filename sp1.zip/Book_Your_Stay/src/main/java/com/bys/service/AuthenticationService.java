package com.bys.service;

import org.keycloak.representations.AccessTokenResponse;

import com.bys.exceptions.UnauthorizedException;
import com.bys.request.LoginRequest;

public interface AuthenticationService {
    public AccessTokenResponse generateToken(LoginRequest login) throws UnauthorizedException;
}

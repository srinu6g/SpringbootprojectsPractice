package com.bys.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bys.request.EmailRequest;
import com.bys.service.EmailService;

@RestController
public class EmailController {

    @Autowired
    private EmailService emailService;

    @PostMapping("/send-email")
    public String sendSimpleEmail(@RequestBody EmailRequest emailRequest) throws MailException {
        emailService.sendEmail(emailRequest);
        return "Email sent successfully";
    }
}
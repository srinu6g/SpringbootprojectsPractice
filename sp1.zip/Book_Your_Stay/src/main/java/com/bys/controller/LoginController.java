package com.bys.controller;



import java.util.Map;

import org.json.JSONException;
import org.keycloak.representations.AccessTokenResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bys.exceptions.BadRequestException;
import com.bys.exceptions.InvalidDataException;
import com.bys.exceptions.LoginTimeoutException;
import com.bys.exceptions.ResourceNotFoundException;
import com.bys.exceptions.UnauthorizedException;
import com.bys.request.GenericOTPPayload;
import com.bys.request.LoginRequest;
import com.bys.request.OtpReqeuest;
import com.bys.request.SmsLogsEnityRequest;
import com.bys.response.VerifyOtpResponse;
import com.bys.security.BaseResponse;
import com.bys.service.AuthenticationService;
import com.bys.service.LoginService;
import com.fasterxml.jackson.core.JsonProcessingException;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/login")
@RequiredArgsConstructor
@Slf4j
public class LoginController {

    private final LoginService loginService;

    private final AuthenticationService authenticationService;

    @GetMapping("/sms/send/otp")
    public BaseResponse<Map<String, String>> sendGenericOneTimePassword(@RequestHeader(required = true) String mobileNumber) throws ResourceNotFoundException, BadRequestException {
        return loginService.sendGenericOneTimePassword(mobileNumber);
    }

    @PostMapping("/sms/verify/otp")
    public ResponseEntity<VerifyOtpResponse> verifyGenericOTP(@RequestHeader(value = "encCode") String encrptedCode, @RequestBody GenericOTPPayload genericOTPPayload, HttpServletRequest request) throws UnauthorizedException, BadRequestException, ResourceNotFoundException, JsonProcessingException {
        return ResponseEntity.ok().body(loginService.verifyOtp(encrptedCode, genericOTPPayload, request));
    }

    @PostMapping("/authenticate")
    public ResponseEntity<AccessTokenResponse> authenticateuser(@RequestBody LoginRequest login) throws UnauthorizedException {
        log.info("login authenticate checking---------");
        return ResponseEntity.ok().body(authenticationService.generateToken(login));
    }
    
    @GetMapping("/refresh/token")
    public BaseResponse<Map<String, String>> getAccesTokenWithRefreshToken(@RequestHeader("refresh_token") String refreshToken) throws BadRequestException, UnauthorizedException, LoginTimeoutException {
        return loginService.getTokenFromRefreshToken(refreshToken);
    }

    @PostMapping("/send/otp")
    public ResponseEntity<String> getOtpService(@RequestBody SmsLogsEnityRequest request, HttpServletRequest req)
            throws ResourceNotFoundException, BadRequestException {
        return ResponseEntity.ok().body(loginService.sendOtpSms(request, req));
    }

    @PostMapping("/save/newpassword")
    public ResponseEntity<String> saveNewPassword(@RequestBody SmsLogsEnityRequest request, HttpServletRequest req)
            throws ResourceNotFoundException {
        return ResponseEntity.ok().body(loginService.saveNewPassword(request, req));
    }

    @PostMapping("/validate")
    public ResponseEntity<Map<String,String>> validateOtp(@RequestBody OtpReqeuest otp, HttpServletRequest req)
            throws InvalidDataException, ResourceNotFoundException {

        return ResponseEntity.ok().body(loginService.validateOtp(otp, req));

    }

    @GetMapping("/generate/otp/{cfmsId}")
    public ResponseEntity<String> otpGeneration(@PathVariable("cfmsId") String cfmsId)
            throws BadRequestException {

        return ResponseEntity.ok().body(loginService.otpGeneration(cfmsId));

    }

    @PostMapping("/update/password")
    public ResponseEntity<AccessTokenResponse> updatePassword(@RequestBody UpdateRequest updateRequest)
            throws UnauthorizedException, JSONException, ResourceNotFoundException, JsonProcessingException {

        return ResponseEntity.ok().body(loginService.updatePassword(updateRequest));

    }



}

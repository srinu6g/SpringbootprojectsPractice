package com.bys.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import javax.sql.DataSource;

@Configuration(proxyBeanMethods = false)
@EnableJpaRepositories(
        basePackages = "com.bys",
        includeFilters = @ComponentScan.Filter(ReadOnlyRepository.class),
        entityManagerFactoryRef = "readOnlyEntityManagerFactory")
public class ReadOnlyEntityManagerConfiguration {

    @Value("${app.readonly.datasource.username}")
    private String username;

    @Value("${app.readonly.datasource.password}")
    private String password;

    @Value("${app.readonly.datasource.url}")
    private String url;

    @Value("${app.readonly.datasource.driver-class-name}")
    private String driverClassName;

    @Bean
    @ConfigurationProperties("app.readonly.datasource")
    public DataSource readOnlyDataSource() {
        return DataSourceBuilder.create()
                .driverClassName(driverClassName)
                .url(url)
                .username(username)
                .password(password)
                .build();
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean readOnlyEntityManagerFactory(EntityManagerFactoryBuilder builder,
                                                                               @Qualifier("readOnlyDataSource") DataSource dataSource) {
        return builder.dataSource(dataSource)
                .packages("com.bys")
                .persistenceUnit("read")
                .build();
    }

}


package com.bys.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app.readwrite.datasource")
public class ValueImportsForEntityManagerConfiguration {
    @Value("${app.readwrite.datasource.username}")
    protected String username;
    @Value("${app.readwrite.datasource.password}")
    protected String password;
    @Value("${app.readwrite.datasource.url}")
    protected String url;
    @Value("${app.readwrite.datasource.driver-class-name}")
    protected String driverClassName;
}

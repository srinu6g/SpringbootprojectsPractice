
package com.bys.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import javax.sql.DataSource;

@Configuration(proxyBeanMethods = false)
@EnableJpaRepositories(
        basePackages = "com.bys",
        excludeFilters = @ComponentScan.Filter(ReadOnlyRepository.class),
        entityManagerFactoryRef = "readWriteEntityManagerFactory")
public class PrimaryEntityManagerConfiguration extends ValueImportsForEntityManagerConfiguration {

    @Bean
    @ConfigurationProperties("app.readwrite.datasource")
    @Primary
    public DataSource readWriteDataSource() {
        return DataSourceBuilder.create()
                .driverClassName(driverClassName)
                .url(url)
                .username(username)
                .password(password)
                .build();
    }

    @Bean
    @Primary
    public LocalContainerEntityManagerFactoryBean readWriteEntityManagerFactory(EntityManagerFactoryBuilder builder,
                                                                                @Qualifier("readWriteDataSource") DataSource dataSource) {
        return builder.dataSource(dataSource)
                .packages("com.bys")
                .persistenceUnit("main")
                .build();
    }

}

package com.bys.entity;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@Getter
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="sms_logs",schema ="apbhavan")
@Entity
@Builder
public class SmsLogsEnity {
	
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "seq_id")
    private Integer seqId;
    @Column(name = "cfms_id")
    private String  cfmsId;
    @Column(name = "mobile_no")
    private String mobileNo;
    @Column(name = "otp")
    private Integer otp;
    @Column(name = "status")
    private String status;
    @Column(name = "ins_time")
    private Timestamp insTime;

}
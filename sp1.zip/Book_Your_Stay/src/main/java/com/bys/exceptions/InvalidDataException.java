package com.bys.exceptions;

public class InvalidDataException extends Exception {

    public InvalidDataException(){}
    public InvalidDataException(String msg)
    {
        super(msg);
    }

}

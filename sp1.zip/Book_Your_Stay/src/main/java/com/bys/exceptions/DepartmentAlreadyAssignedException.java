package com.bys.exceptions;

public class DepartmentAlreadyAssignedException extends RuntimeException {
    public DepartmentAlreadyAssignedException(String message) {
        super(message);
    }

    public DepartmentAlreadyAssignedException(String message, Throwable cause) {
        super(message, cause);
    }
}

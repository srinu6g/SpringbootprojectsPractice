package com.bys.serviceimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.keycloak.authorization.client.AuthzClient;
import org.keycloak.authorization.client.Configuration;
import org.keycloak.representations.AccessTokenResponse;
import org.springframework.stereotype.Service;

import com.bys.entity.Users;
import com.bys.exceptions.UnauthorizedException;
import com.bys.repository.UsersRepository;
import com.bys.request.LoginRequest;
import com.bys.service.AuthenticationService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthenticationServiceImpl extends KeycloakParameters implements AuthenticationService {

    private final UsersRepository usersRepository;

    public AccessTokenResponse generateToken(LoginRequest login) throws UnauthorizedException {
       List<Users> userList = usersRepository.findAllByCfmsIdAndIsActive(login.getUsername(),true);

        if (userList == null ||userList.isEmpty() ) {
            throw new UnauthorizedException("User does not exist");
        }


        Users user=userList.get(0);

        try {
            Map<String, Object> clientCredentials = new HashMap<>();
            clientCredentials.put("secret", clientSecret);
            clientCredentials.put("grant_type", "password");
            Configuration configuration = new Configuration(authServerUrl, realm, clientId, clientCredentials, null);
            AuthzClient authzClient = AuthzClient.create(configuration);

            AccessTokenResponse accessToken = authzClient.obtainAccessToken(login.getUsername(), login.getPassword());
            Map<String, Object> otherClaims = new HashMap<>();
            otherClaims.put("userName", user.getName());
            otherClaims.put("roleName", user.getRole().getRoleName());
            //Optional<String> mobOrCfmsId=Optional.ofNullable(Optional.ofNullable(user.getMobile()).orElse(user.getCfmsId()));
            otherClaims.put("mobOrCfmsId",getCfmsIdOrMobile(user) );
            accessToken.setRefreshToken(accessToken.getRefreshToken());
            accessToken.setOtherClaims("UserDetails", otherClaims);
            
            return accessToken;
        } catch (Exception ex) {
            throw new UnauthorizedException("Invalid UserName or Password");
        }
    }

    private String getCfmsIdOrMobile(Users user) {
        return List.of("RC", "ARC", "LO").contains(user.getRole().getRoleName())
                ? user.getMobile()
                : user.getCfmsId();
    }
}

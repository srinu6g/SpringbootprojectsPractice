package com.bys.serviceimpl;

import org.springframework.beans.factory.annotation.Value;

public class KeycloakParameters {
	@Value("${keycloak.auth-server-url}")
	public String authServerUrl;
	@Value("${keycloak.realm}")
	public String realm;
	@Value("${keycloak.resource}")
	public String clientId;
	@Value("${clientSecret}")
	public String clientSecret;
	@Value("${kc.admin.username}")
	public String userName;
	@Value("${kc.admin.password}")
	public String password;
	@Value("${kc.cli.clientid}")
	public String cliClientId;
	@Value("${refreshtokenurl}")
	public String refreshTokenUrl;
}

package com.bys.serviceimpl;


import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.authorization.client.AuthzClient;
import org.keycloak.authorization.client.Configuration;
import org.keycloak.representations.AccessTokenResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.bys.entity.Users;
import com.bys.exceptions.LoginTimeoutException;
import com.bys.exceptions.ResourceNotFoundException;
import com.bys.exceptions.UnauthorizedException;
import com.bys.request.LoginRequest;
import com.bys.response.VerficationResponse;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class KeyCloakServiceImpl extends KeycloakParameters {

	Logger logger = LoggerFactory.getLogger(KeyCloakServiceImpl.class);

	private final RestTemplate restTemplate;
	private static final String OTP ="N1dh1@123";

	private static final String UNAUTHORIZED_ACCESS = "Unauthorized access";
	private static final String PASS_WORD = "password";

	private static final String GRANT_TYPE = "grant_type";
	private static final String SECRET = "secret";

	private static final String REFRESH_TOKEN = "refresh_token";

	private final UserController userController;

	private final UsersRepository usersRepository;


	public Map<String, String> getTokenFromKeycloak(String mobileNumber) throws UnauthorizedException {
		Map<String, String> data = new HashMap<>();

		try {
			Map<String, Object> clientCredentials = new HashMap<>();
			clientCredentials.put(SECRET, clientSecret);
			clientCredentials.put(GRANT_TYPE, PASS_WORD);

			Configuration configuration = new Configuration(authServerUrl, realm, clientId, clientCredentials, null);
			AuthzClient authzClient = AuthzClient.create(configuration);

			AccessTokenResponse accessToken = authzClient.obtainAccessToken(mobileNumber, OTP);

			logger.info("accessToken received");
			data.put("access_token", accessToken.getToken());
			data.put(REFRESH_TOKEN, accessToken.getRefreshToken());
			return data;
		} catch (Exception ex) {
			throw new UnauthorizedException("InValid OTP!!");
		}
	}

	public String resetpassword(String userName, String password) throws JSONException, ResourceNotFoundException {
		ResponseEntity<String> restTemplateResponse = null;
		try {

			VerficationResponse res = adminToken();
			if (res != null) {
				Keycloak keycloak = getKeyCloakInstance();
				UsersResource usersResource = getUsersResource(keycloak);
				String userId = usersResource.search(userName).get(0).getId();
				String url = authServerUrl + "/admin/realms/" + realm + "/users/" + userId + "/reset-password";
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.setBearerAuth(res.getAccessToken());
				logger.info("headers = {}", headers);

				org.json.JSONObject obj = new org.json.JSONObject();
				obj.put("type", "password");
				obj.put("value", password);
				obj.put("temporary", false);

				HttpEntity<MultiValueMap<String, Object>> headersRequest = new HttpEntity(obj.toString(), headers);
				restTemplateResponse = this.restTemplate.exchange(url, HttpMethod.PUT, headersRequest, String.class);
				if (restTemplateResponse != null) {
					return restTemplateResponse.getBody();
				}
			}
		} catch (Exception e) {
			int t = e.getMessage().length();
			String s = e.getMessage().substring(18, t);
			org.json.JSONObject obj = new org.json.JSONObject(s);
			throw new ResourceNotFoundException(obj.getString("error_description"));
		}

		return null;

	}
	private VerficationResponse adminToken()  {

		VerficationResponse res = userController.getAdminToken();
		if (res != null) {
			return res;
		}
		return null;
	}

	public Keycloak getKeyCloakInstance() {
		return Keycloak.getInstance(authServerUrl, realm, this.userName, this.password, this.cliClientId);
	}

	public UsersResource getUsersResource(Keycloak keycloak) {
		return keycloak.realm(realm).users();
	}

	public String getTokenFromRefreshToken(String refreshToken) throws LoginTimeoutException, UnauthorizedException {
		
		ResponseEntity<VerficationResponse> response = null;
		try {

			String url = refreshTokenUrl.trim();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
			map.add("client_id", clientId);
			map.add(GRANT_TYPE, REFRESH_TOKEN);
			map.add(REFRESH_TOKEN, refreshToken);
			map.add("client_secret", clientSecret);


			HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
			response = this.restTemplate.postForEntity(url, request, VerficationResponse.class);

		} catch (HttpStatusCodeException e) {

			int status = e.getRawStatusCode();

			if (status == 400) {

				throw new LoginTimeoutException("Invalid Token ");
			}
		}

		if (response == null || response.getBody() == null) {
			throw new UnauthorizedException(UNAUTHORIZED_ACCESS);
		}
		VerficationResponse body = response.getBody();
		if (body == null || body.getAccessToken() == null || body.getAccessToken().isEmpty()) {
			throw new UnauthorizedException(UNAUTHORIZED_ACCESS);
		}
		 return body.getAccessToken();

	}

	public AccessTokenResponse generateToken(LoginRequest login) throws UnauthorizedException {
		try {
			Users user = usersRepository.findByIsActiveAndMobileOrCfmsId(true,login.getUsername());
			if (user==null) {
				throw new UnauthorizedException("You're Unauthorized to access");
			} else {
				Map<String, Object> clientCredentials = new HashMap<>();
				clientCredentials.put(SECRET, clientSecret);
				clientCredentials.put(GRANT_TYPE, PASS_WORD);
				Configuration configuration = new Configuration(authServerUrl, realm, clientId, clientCredentials, null);
				AuthzClient authzClient = AuthzClient.create(configuration);
				logger.info("Login UserName: {}", login.getUsername());
				logger.info("Login User Password: {}", login.getPassword());
				AccessTokenResponse accessToken = authzClient.obtainAccessToken(login.getUsername(), login.getPassword());
				return accessToken;
			}
		} catch (Exception ex) {

			throw new UnauthorizedException(ex.getMessage().equals("You're Unauthorized to access") ? ex.getMessage() : "Invalid UserName or Password");
		}
	}

}

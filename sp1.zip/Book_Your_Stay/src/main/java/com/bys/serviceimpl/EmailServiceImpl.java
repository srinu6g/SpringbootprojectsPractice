package com.bys.serviceimpl;


import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.bys.request.EmailRequest;
import com.bys.service.EmailService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmailServiceImpl implements EmailService {


    private JavaMailSender javaMailSender;

    public void sendEmail(EmailRequest emailRequest) {

        SimpleMailMessage message=new SimpleMailMessage();
        message.setTo(emailRequest.getTo());
        message.setSubject(emailRequest.getSubject());
        message.setText(emailRequest.getText());
        message.setFrom("");

        javaMailSender.send(message);
    }


}

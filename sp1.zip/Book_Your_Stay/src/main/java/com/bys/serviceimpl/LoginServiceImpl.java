package com.bys.serviceimpl;

import java.security.SecureRandom;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import org.json.JSONException;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.representations.AccessTokenResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bys.entity.SmsLogsEnity;
import com.bys.entity.Users;
import com.bys.exceptions.BadRequestException;
import com.bys.exceptions.InvalidDataException;
import com.bys.exceptions.LoginTimeoutException;
import com.bys.exceptions.ResourceNotFoundException;
import com.bys.exceptions.UnauthorizedException;
import com.bys.repository.SmsLogsEnityRepo;
import com.bys.repository.UsersRepository;
import com.bys.request.GenericOTPPayload;
import com.bys.request.LoginRequest;
import com.bys.request.OtpReqeuest;
import com.bys.request.SmsLogsEnityRequest;
import com.bys.request.UpdateRequest;
import com.bys.response.VerifyOtpFailureResponse;
import com.bys.response.VerifyOtpResponse;
import com.bys.security.BaseResponse;
import com.bys.service.LoginService;
import com.bys.utils.AESUtils;
import com.bys.utils.CommonFunctionUtils;
import com.bys.utils.DataValidations;
import com.bys.utils.StatusMasterConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LoginServiceImpl implements LoginService {

    public static final String MOBILE_NUMBER = "MobileNumber";
    public static final String ATTEMPTS_COUNT = "attemptsCount";
    public static final String OTP_SENT_TIME = "otpSentTime";

    public static final String S_S = "SMS SENT SUCCESSFULLY";
    public static final String NETWORK_ERROR = "OTP Not Sent. Mobile Network Error!!!";
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private static final String ERRORMSG = "Your OTP is Expired Please Resend OTP";
    private final CommonFunctionUtils commonFunctionUtils;

    private final UsersRepository usersRepo;

    private final KeyCloakServiceImpl keyCloakServiceImpl;

    private final SmsLogsEnityRepo smsLogsEnityRepo;


    @Override
    public BaseResponse<Map<String, String>> sendGenericOneTimePassword(String mobileNumber) throws ResourceNotFoundException, BadRequestException {
        Map<String, String> response = new HashMap<>();



        String otp;
        String regEx = "^\\d+$";
        if (!DataValidations.nullValidation(mobileNumber) || !mobileNumber.matches(regEx) || mobileNumber.length() != 10) {
            throw new ResourceNotFoundException("Invalid Mobile Number");
        }
        Integer countOfData = usersRepo.countByMobile(mobileNumber);
        if (countOfData == 0) throw new BadRequestException("Mobile Number Not Registered");
        if (countOfData >= 1) {
            if(mobileNumber.equals("9219219219") ||mobileNumber.equals("6333333333")||mobileNumber.equals("6444444444")||mobileNumber.equals("6222222222")||mobileNumber.equals("6111111111") || mobileNumber.equals("6999999999") || mobileNumber.equals("6555555555"))
                 otp = "551230";
            else
                otp = generateSecureOTP(5);
            if (DataValidations.nullValidation(otp) && otp.length() == 5) otp = "9" + otp;

            String message = "Your OTP for Logging  into AP Bhavan application  is " + otp.trim() + " -GOVTAP";
             commonFunctionUtils.sendSingleSMS(mobileNumber, message, StatusMasterConstants.SMS_TEMPID_SMS_STRIKER_OTP);

            LocalDateTime insertedTime = LocalDateTime.now(ZoneId.of(StatusMasterConstants.ASIA_KOLKATA));

            Map<String, Object> userLoginData = new HashMap<>();
            userLoginData.put(MOBILE_NUMBER, mobileNumber);
            userLoginData.put("otp", otp);
            userLoginData.put(ATTEMPTS_COUNT, 5);
            userLoginData.put(OTP_SENT_TIME, insertedTime.toString());

            String jsonObject = commonFunctionUtils.getMapTojsonString(userLoginData);
            String encryptedData = AESUtils.encrypt(jsonObject);
            Users user = usersRepo.findByIsActiveAndMobileOrCfmsId(true,mobileNumber);
            response.put("roleName", user.getRole().getRoleName());
            response.put("SUCCESS", "Otp sent successfully");
            response.put("token_data", encryptedData);
            return new BaseResponse<Map<String, String>>().createResponse(200, response);
        }
        throw new BadRequestException(" MobileNumbers Not Exist");
    }

    @Transactional
    @Override
    public VerifyOtpResponse verifyOtp(String encryptedCode, GenericOTPPayload genericOTPPayload, HttpServletRequest request) throws UnauthorizedException, BadRequestException, ResourceNotFoundException, JsonProcessingException {
        VerifyOtpResponse response = new VerifyOtpResponse();
        VerifyOtpFailureResponse failureResponse = new VerifyOtpFailureResponse();


        if (!DataValidations.nullValidation(genericOTPPayload.getMobileNumber()) && !DataValidations.nullValidation(genericOTPPayload.getOtp()))
            throw new UnauthorizedException("Invalid Mobile Number or Otp");

        String decrypt = AESUtils.decrypt(encryptedCode);
        Map<String, Object> decryptedMapData = commonFunctionUtils.getMapObjectwithJsonString(decrypt);

        String encryptedMobileNumber = decryptedMapData.get(MOBILE_NUMBER).toString();
        String encryptedOtp = decryptedMapData.get("otp").toString();
        String encryptedOtpSentTime = decryptedMapData.get(OTP_SENT_TIME).toString();
        String encryptedAttemptsCount = decryptedMapData.get(ATTEMPTS_COUNT).toString();

        if (Integer.parseInt(encryptedAttemptsCount) == 0) throw new UnauthorizedException("Login Failed");

        if (!(encryptedOtp.equals(genericOTPPayload.getOtp()) && encryptedMobileNumber.equals(genericOTPPayload.getMobileNumber()))) {
            Map<String, Object> userLoginData = new HashMap<>();
            userLoginData.put(MOBILE_NUMBER, encryptedMobileNumber);
            userLoginData.put("otp", encryptedOtp);
            userLoginData.put(ATTEMPTS_COUNT, Integer.parseInt(encryptedAttemptsCount) - 1);
            userLoginData.put(OTP_SENT_TIME, encryptedOtpSentTime);

            String jsonObject = commonFunctionUtils.getMapTojsonString(userLoginData);

            String encryptedData = AESUtils.encrypt(jsonObject);

            failureResponse.setLimits(Integer.parseInt(encryptedAttemptsCount) - 1);
            failureResponse.setDescription("Enter the Correct Otp");
            failureResponse.setTokenData(encryptedData);
            throw new UnauthorizedException("InValid OTP!!");
        }
        LocalDateTime parsedTime = LocalDateTime.parse(encryptedOtpSentTime);
        LocalDateTime currentTime = LocalDateTime.now(ZoneId.of(StatusMasterConstants.ASIA_KOLKATA));
        Duration duration = Duration.between(parsedTime, currentTime);
        long secondsElapsed = duration.getSeconds();
        if (secondsElapsed > 18000) {
            throw new BadRequestException("Time Expired Login Again!");
        }

        if (!(genericOTPPayload.getOtp().equals(encryptedOtp) && genericOTPPayload.getMobileNumber().equals(encryptedMobileNumber))) {
            throw new BadRequestException("Failed to Login Can Not Authenticate");
        }

        Map<String, String> token = keyCloakServiceImpl.getTokenFromKeycloak(genericOTPPayload.getMobileNumber());
        Users usersRegistrationDetails = usersRepo.findByMobileAndIsActive(genericOTPPayload.getMobileNumber(), true);

        if (usersRegistrationDetails == null) {
            throw new ResourceNotFoundException("Can Not Find Role for Mobile Number: " + genericOTPPayload.getMobileNumber());
        }

        if (usersRegistrationDetails.getId() == null && usersRegistrationDetails.getRole().getId() != 1)
            throw new BadRequestException("Userid Not Exist");

        response.setUserName(usersRegistrationDetails.getName());
        response.setRoleName(usersRegistrationDetails.getRole().getRoleName());
        response.setMobOrCfmsId(
                Optional.ofNullable(usersRegistrationDetails.getMobile())
                        .orElse(usersRegistrationDetails.getCfmsId())
        );
        response.setAccess_token(token.get("access_token"));
        response.setRefresh_token(token.get("refresh_token"));

        return response;
    }

    @Override
    public BaseResponse<Map<String, String>> getTokenFromRefreshToken(String refreshToken) throws BadRequestException, LoginTimeoutException, UnauthorizedException {
        Map<String, String> resultMap = new HashMap<>();

        if (refreshToken == null) throw new BadRequestException("Invalid Token");
        String accessToken = keyCloakServiceImpl.getTokenFromRefreshToken(refreshToken);
        if (accessToken == null)
            throw new BadRequestException("Internal Error");
        resultMap.put("acces_token", accessToken);
        return new BaseResponse<Map<String, String>>().createResponse(200, resultMap);
    }

    @Override
    public String sendOtpSms(SmsLogsEnityRequest request, HttpServletRequest req) throws ResourceNotFoundException, BadRequestException {

        Users user = usersRepo.findByIsActiveAndMobileOrCfmsId(true, request.getCfmsId());
        if (user == null || user.getCfmsId() == null) {
            throw new ResourceNotFoundException("LOGIN ID DOESN'T EXIST");
        }

        String mobile = user.getMobile();
        if (mobile == null || !mobile.matches("^[0-9]{10}$")) {
            throw new ResourceNotFoundException("Mobile number is not valid or null");
        }

        String otpCode = commonFunctionUtils.random();
        if (otpCode == null || otpCode.length() < 5) {
            throw new IllegalArgumentException("Generated OTP code is invalid: " + otpCode);
        }
        String otp = otpCode.length() > 5 ? otpCode.substring(0, 5) : "9" + otpCode;

        SmsLogsEnity smsEntity = SmsLogsEnity.builder()
                .cfmsId(request.getCfmsId())
                .mobileNo(mobile)
                .otp(Integer.parseInt(otp.trim()))
                .insTime(CommonFunctionUtils.getCurrentTimeStamp())
                .status("Otp Sent")
                .build();

        logger.info("SmsLogsEnity::{}", smsEntity);
        smsLogsEnityRepo.save(smsEntity);

        String message = String.format("Your OTP for logging into AP Bhavan application is %s -GOVTAP", otp.trim());
        String responseCode = commonFunctionUtils.sendSingleSMS(
                mobile,
                message,
                StatusMasterConstants.SMS_TEMPID_SMS_STRIKER_OTP
        );

        if ("Success".equalsIgnoreCase(responseCode.trim())) {
            logger.info(S_S);
            return S_S;
        } else {
            logger.error(NETWORK_ERROR);
            return NETWORK_ERROR;
        }
    }


    @Override
    public Map<String, String> validateOtp(OtpReqeuest otp, HttpServletRequest req) throws InvalidDataException, ResourceNotFoundException {
        SmsLogsEnity smsLogsEntity = smsLogsEnityRepo.validateOpt(otp.getCfmsId());
        Map<String, String> resp = new LinkedHashMap<>();
        Timestamp generatedDate = Optional.ofNullable(smsLogsEntity)
                .map(SmsLogsEnity::getInsTime)
                .orElse(new Timestamp(System.currentTimeMillis()));
        logger.info("generatedDate*****{} ", generatedDate);
        var expireDate = new Date(generatedDate.getTime() + TimeUnit.MINUTES.toMillis(10));
        logger.info("expireDate******{}", expireDate);
        if (new Date().before(expireDate)) {

            if (smsLogsEntity.getOtp().toString().trim().equals(otp.getOtp().trim())) {
                resp.put("SCODE", "01");
                resp.put("SDESC", "OTP verified successfully.");
                return resp;
            } else {
                resp.put("SCODE", "02");
                resp.put("SDESC", "The OTP entered is incorrect. Please check and try again.");
                return resp;
            }
        }
        resp.put("SCODE", "02");
        resp.put("SDESC", ERRORMSG);

        return resp;
    }


    @Override
    public String saveNewPassword(SmsLogsEnityRequest req, HttpServletRequest request) throws ResourceNotFoundException {
        try {

            if (req.getConfirmPassword().equals(req.getNewPassword())) {
                keyCloakServiceImpl.resetpassword(String.valueOf(req.getCfmsId()), req.getNewPassword());
                return "successfully changed";
            } else {
                return "confirm password and new password are not same";
            }
        } catch (Exception e) {
            throw new ResourceNotFoundException("unable to process");

        }

    }

    public String generateSecureOTP(int length) {
        SecureRandom secureRandom = new SecureRandom();
        StringBuilder otpBuilder = new StringBuilder(length);
        String characters = "0123456789";

        for (int i = 0; i < length; i++) {
            int randomIndex = secureRandom.nextInt(characters.length());
            otpBuilder.append(characters.charAt(randomIndex));
        }

        return otpBuilder.toString();
    }

    public String otpGeneration(String cfmsId) throws BadRequestException {

        Users user = usersRepo.findByIsActiveAndMobileOrCfmsId(true,cfmsId);
        String mobileNumber = user.getMobile();
        String otpCode = commonFunctionUtils.random();
        if (otpCode != null && otpCode.length() == 5)
            otpCode = "9" + otpCode;

        String message = "Your OTP for Logging  into AP Bhavan application  is " + otpCode + " -GOVTAP";
        String responseCode = commonFunctionUtils.sendSingleSMS(mobileNumber, message, StatusMasterConstants.SMS_TEMPID_SMS_STRIKER_OTP);

        if (responseCode.trim().equals("Success")) {
            logger.info(S_S);

            return S_S;
        } else {
            logger.info(NETWORK_ERROR);

            return NETWORK_ERROR;
        }
    }

    @Override
    public AccessTokenResponse updatePassword(UpdateRequest updateRequest) throws UnauthorizedException,
            JSONException, ResourceNotFoundException, JsonMappingException, JsonProcessingException {
        Keycloak keycloak = keyCloakServiceImpl.getKeyCloakInstance();

        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername(updateRequest.getUserName());
        loginRequest.setPassword(updateRequest.getPassword());
        AccessTokenResponse token = keyCloakServiceImpl.generateToken(loginRequest);

        if (token == null || "".equals(token.getToken())) {
            throw new UnauthorizedException("Unauthorized");
        }

        if (!updateRequest.getNewPassword().equals(updateRequest.getConfirmPassword())) {
            throw new UnauthorizedException("New password and confirm passwords did not match");
        }
        keyCloakServiceImpl.resetpassword(updateRequest.getUserName() + "", updateRequest.getNewPassword());
        loginRequest.setPassword(updateRequest.getNewPassword());
        return keyCloakServiceImpl.generateToken(loginRequest);
    }


}

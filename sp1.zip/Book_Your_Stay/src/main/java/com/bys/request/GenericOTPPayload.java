package com.bys.request;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GenericOTPPayload {

    @NotNull(message = "MobileNumber shoud not be null")
    private String mobileNumber;

    //@NotNull(message = "OTP shoud not be null")
    private String otp;

}
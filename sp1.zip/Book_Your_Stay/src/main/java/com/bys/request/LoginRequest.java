package com.bys.request;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class LoginRequest {

    private String username;
    private String password;
    private String otp;

}

package com.bys.security;

import java.io.IOException;

import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class LoginAuthenticationEntryPoint implements org.springframework.security.web.AuthenticationEntryPoint {

	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException, ServletException {

		final String bearer = (String) request.getAttribute("bearer");

		if (bearer != null) {
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, bearer);
		} else {
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Invalid request");
		}
	}

}
package com.bys.security;

import java.io.IOException;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtRequestFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        final String requestTokenHeader = request.getHeader("Authorization");

        if ("OPTIONS".equals(request.getMethod())
                || request.getRequestURL().toString().contains("/swagger")
                || request.getRequestURL().toString().contains("/login")
                || request.getRequestURL().toString().contains("/api-docs")
                || request.getRequestURL().toString().contains("/userSmsSent")
                || request.getRequestURL().toString().contains("/urlData/employeedetaiils")
                || request.getRequestURL().toString().contains("/dump/users")
                || request.getRequestURL().toString().contains("/urlData/districtsandmandals")
                || request.getRequestURL().toString().contains("/actuator/health")
                || request.getRequestURL().toString().contains("/workflowdetails")
                || request.getRequestURL().toString().contains("/bys/userDetails")
                ||request.getRequestURL().toString().contains("bys/login")
                || request.getRequestURL().toString().contains("/getRefreshToken")
                || request.getRequestURL().toString().contains("/urlData/ispensionerornot")
                || request.getRequestURL().toString().contains("/helpdesk/contacts")
        ) {

                response.setStatus(HttpServletResponse.SC_OK);
                filterChain.doFilter(request, response);

        } else {
            if (requestTokenHeader == null || !requestTokenHeader.startsWith("Bearer ")) {
                request.setAttribute("bearer", "Missing authentication token");
                response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
            }
            else {
                filterChain.doFilter(request, response);
            }
        }
    }
}
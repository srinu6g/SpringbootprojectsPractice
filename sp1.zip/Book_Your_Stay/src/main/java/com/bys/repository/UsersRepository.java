package com.bys.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.bys.entity.Users;

@Repository
public interface UsersRepository extends JpaRepository<Users, Long>, JpaSpecificationExecutor<Users> {

    Integer countByMobile(String mobileNumber);

	List<Users> findAllByCfmsIdAndIsActive(String username, boolean b);

	Users findByIsActiveAndMobileOrCfmsId(boolean b, String mobileNumber);


}

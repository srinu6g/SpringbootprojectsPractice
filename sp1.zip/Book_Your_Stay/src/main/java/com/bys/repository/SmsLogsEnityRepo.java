package com.bys.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bys.entity.SmsLogsEnity;



@Repository
public interface SmsLogsEnityRepo extends JpaRepository<SmsLogsEnity,Long> {
	
    @Query(nativeQuery =true,value="select * from apbhavan.sms_logs s where s.cfms_id=:cfmsId order by s.ins_time desc limit 1")
    SmsLogsEnity validateOpt(String cfmsId);
}
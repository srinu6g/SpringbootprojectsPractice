package com.bys.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bys.entity.RoleMst;

public interface RoleMstRepository extends JpaRepository<RoleMst,Long>{

	RoleMst findByRoleId(Integer roleId);

	RoleMst findByRoleName(String roleName);

	

}

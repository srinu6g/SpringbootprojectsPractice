package com.bys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookYourStayApplicationTests {

	@Test
	void contextLoads() {
	}

}

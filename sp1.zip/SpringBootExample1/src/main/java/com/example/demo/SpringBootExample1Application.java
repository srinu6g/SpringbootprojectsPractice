package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootExample1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootExample1Application.class, args);
		
	}

}

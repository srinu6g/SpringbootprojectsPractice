


package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.service.LoginService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class LoginController {
	
	// injecting service class inside controller class
	@Autowired
	LoginService loginService;
	
	
	@RequestMapping("/load")
	public String loadingLoginform()
	
	{
		return "login";
	}
	
	@RequestMapping("/print/response")
	public ModelAndView printingRespone()
	{
		
		ModelAndView mv=new ModelAndView();
		
		mv.setViewName("login");
		mv.addObject("msg","Hello world am there");
		return mv;
		
	}
	
	
	// the above mapping when ever hit the url /print/response
	//corresponding request method excuted 
	//modelandview tells that model is nothing but some logic
	//view means what ever logic we receive from model to send view  layer
	
	
	@RequestMapping("/loadDetails")
	public String loadingLoginformpage()
	
	{
		return "Loginform";
	}
	
	// this below code loading fb details and sending response to view layer as succesfull login user
	//but that is not coming from service and repository
	/*@PostMapping("/load/fbdetails")
	public ModelAndView printingResponeFacebook(HttpServletRequest request)
	{
		String email=request.getParameter("email");
		String contact=request.getParameter("number");
		
		
		ModelAndView mv=new ModelAndView();
		mv.setViewName("result");
	
		System.out.println(email);
		System.out.println(contact);
		mv.addObject("msg","user login successfully :"+email);
		
		return mv;
		
	}*/
	
	@PostMapping("/load/fbdetails")
	public ModelAndView printingResponeFacebook(HttpServletRequest request)
	{
		String email=request.getParameter("email");
		String contact=request.getParameter("number");
		
		// TODO forwarding request to service layer 
		
		String res=loginService.createUser(email,contact);
		
		
		ModelAndView mv=new ModelAndView();
		mv.setViewName("result");
	
		System.out.println(email);
		System.out.println(contact);
		mv.addObject("msg",res +": "+email);
		
		return mv;
		
	}
	
	
	
}

package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.LoginRepository;
import com.example.demo.entity.UserLogin;

@Service
public class LoginService {
	
	//connection between service and repository
	@Autowired
	LoginRepository loginRepository;
	
	public LoginService()
	{
		System.out.println("service class instanized");
	}

	public String createUser(String email, String contact) {
		// TODO Auto-generated method stub
		
		// TODO forward req to repositotry layer
		
		UserLogin us=new UserLogin();
		us.setEmail(email);
		us.setContact(contact);
		
		if(loginRepository.findById(email).isPresent())
		{
			return "Email already exist : plaese enter new email....";
		}
	
		
		loginRepository.save(us);
		
		
		
		
		return "login success ";		
	}
	
	

}

package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

@SpringBootApplication
public class SpringBootExampleDemoApplication {

	public static void main(String[] args) {
		
		ConfigurableApplicationContext context=  SpringApplication.run(SpringBootExampleDemoApplication.class, args);
		//Student s1= (Student) context.getBean(Student.class);
		
		
		// college dta //
		
		System.out.println("***************88College class info**************");
		College c1=context.getBean(College.class);
		System.out.println(c1.getKrish().getName());
		
		
	}
	

	@Bean("s2")
	public Student secondStuent()
	{
		Student s2=new Student();
		s2.setSid(2);
		s2.setName("praveen");
		s2.setAge(24);
		return s2;
		
		
		
	}
	

}

package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.stereotype.Component;

@Component
public class College {
	
	private String branches;
	private int totaStudents;
	
	
	@Autowired
	private Student krish;
	public String getBranches() {
		return branches;
	}
	public void setBranches(String branches) {
		this.branches = branches;
	}
	public int getTotaStudents() {
		return totaStudents;
	}
	public void setTotaStudents(int totaStudents) {
		this.totaStudents = totaStudents;
	}
	public Student getKrish() {
		return krish;
	}
	public void setKrish(Student krish) {
		this.krish = krish;
	}
	
	
	
	

}

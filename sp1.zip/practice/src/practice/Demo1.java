/*
 * package practice;
 * 
 * public class Demo1 implements Runnable {
 * 
 * 
 * 
 * public void start() { for(int i=0;i<5;i++) { System.out.println("Hiii"); } }
 * 
 * public void run() { System.out.println("am run "); }
 * 
 * public static void main(String[] args) { // TODO Auto-generated method stub
 * 
 * 
 * for(int i=0;i<5;i++) { System.out.println("hello"); }
 * 
 * 
 * 
 * 
 * Thread t1=new Thread(); t1.start();
 * 
 * 
 * Runnable r1=new Demo1(); r1.run();
 * 
 * Runnable r2=new Demo1();
 * 
 * Runnable r3=new Demo1();
 * 
 * 
 * 
 * Demo1 d1=new Demo1(); d1.start();
 * 
 * }
 * 
 * }
 */


package practice;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Demo1
{
	public static void main(String[] args) {
		
	
		
		
		ConcurrentHashMap<String,String> m=new ConcurrentHashMap<>();
		
		m.put("devara","ntr");
		
		m.put("puspa","arjun");
		
		m.put("Gunturkaram","mahesh");
		
		m.put("raja","raviteja");
		
		m.put("dooku maharaj","balayya");
		
		//System.out.prin
		
		
	
		Iterator<Map.Entry<String,String>> keys=m.entrySet().iterator();
		
		if(keys.hasNext())
		{
			//m.remove(keys);

			System.out.println("keys:"+keys.next()+" "+"Values:"+keys.next());
		

		}
		
		//System.out.println(m);
	
			
	}
}




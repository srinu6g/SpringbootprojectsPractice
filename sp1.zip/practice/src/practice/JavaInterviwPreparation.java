package practice;

import java.util.Scanner;

public class JavaInterviwPreparation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// to find odd or even number
		
		/*
		 * Scanner sc=new Scanner(System.in); System.out.println("Enter your numver");
		 * int number=sc.nextInt();
		 * 
		 * System.out.println("your number is :: "+number);
		 * 
		 * if(number%2==0) { System.out.println("Even"); } else
		 * System.out.println("Odd");
		 */
		
		
		//swap 
		
		/*
		 * Scanner sc=new Scanner(System.in); System.out.println("Enter first number");
		 * int a=sc.nextInt(); System.out.println("Enter second number"); int
		 * b=sc.nextInt();
		 * 
		 * System.out.println("Before swapping "+a+ " " +b);
		 * 
		 * a=a+b; b=a-b; a=a-b;
		 * 
		 * System.out.println("after swapping "+a+ " " +b);
		 */
		
		
		//sum of the digits of a given number
		
		/*
		 * Scanner sc=new Scanner(System.in);
		 * 
		 * System.out.println("Enter number");
		 * 
		 * int num=sc.nextInt();
		 * 
		 * System.out.println(num);
		 * 
		 * int res=0;
		 * 
		 * while(num>0) { int rem=num%10; num=num/10;
		 * 
		 * res=res+rem;
		 * 
		 * }
		 * 
		 * System.out.println("your sum of digits is "+res);
		 */
		
		// palindrome
		/*
		 * Scanner sc=new Scanner(System.in);
		 * 
		 * System.out.println("enter number"); int num=sc.nextInt();
		 * 
		 * int res=0; int temp=num; while(num>0) { int rem=num%10; res=res * 10+rem;
		 * num=num/10; } System.out.println(res);
		 * 
		 * if(res==temp) { System.out.println("Palindrome"); } else
		 * System.out.println("Not a palindrome");
		 * 
		 */
		
		// revrse of a given nuber
		
		
		/*
		 * Scanner sc=new Scanner(System.in);
		 * 
		 * System.out.println("enter number"); int num=sc.nextInt();
		 * 
		 * int res=0;
		 * 
		 * while(num>0) { int rem=num%10; res=res * 10+rem; num=num/10; }
		 * 
		 * System.out.println("Revrse of a gievn number is :"+res);
		 * 
		 */
/*		// calculate no of digits of a given number
		

			Scanner sc=new Scanner(System.in);
			 
			 System.out.println("enter number");
			 int num=sc.nextInt();
			 
			 int count=0; 
		if(num!=0)
		{
			 while(num>0)
			 { 
				 count++;
				 num=num/10; 
			 }
			 
			 System.out.println("no of digits of a gievn number is :"+count);
			
		}
		else
			System.out.println("no of digits of a gievn number is :"+1);
		 
		 sc.close();*/
		 
		//Armstronng	 
		 
		 
		/*
		 * Scanner sc=new Scanner(System.in);
		 * 
		 * System.out.println("enter number"); int num=sc.nextInt();
		 * 
		 * 
		 * int res=0; int num1=num; int count=0; int temp=num; while(num1>0) { count++;
		 * num1=num1/10; }
		 * 
		 * System.out.println(count); while(num>0) { int rem= num%10; res=(int)
		 * ((Integer)res+Math.pow(rem,count)); num=num/10; } System.out.println(res);
		 * if(res==temp) { System.out.println("armstrong"); } else
		 * System.out.println("Not a armstrong");
		 */	
		
		
		//factorial of a given number
		/*
		 * Scanner sc=new Scanner(System.in); System.out.println("Enter number"); int
		 * num=sc.nextInt();
		 * 
		 * for(int i=1;i<=num;i++) { if(num%i==0) {
		 * 
		 * System.out.print(i+" "); } }
		 */
		
		// prime number of a program
		
		/*
		 * Scanner sc=new Scanner(System.in); System.out.println("Enter number"); int
		 * num=sc.nextInt(); int count=0; for(int i=1;i<=num;i++) { if(num%i==0) {
		 * count++; } } if(count==2) { System.out.println("Prime number"); }
		 * 
		 * else System.out.println(" Not a Prime number");
		 */
		
		// i want print range of prime numbers
		
		/*
		 * Scanner sc=new Scanner(System.in); System.out.println("Enter first number");
		 * int n1=sc.nextInt();
		 * 
		 * System.out.println("Enter second number"); int n2=sc.nextInt();
		 * 
		 * 
		 * if(n1<2) n1=2;
		 * 
		 * for(int i=n1;i<=n2;i++) { int count=0; for(int j=1;j<=i;j++) { if(i%j==0) {
		 * count++; } } if(count==2) System.out.print(i+" ");
		 * 
		 * 
		 * }
		 */
	//**********Strings ***********************************//
		
		
		// how to print revrse of a given String
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string");
		String str=sc.nextLine();
		
		System.out.println(str.length());
		//String str=sc.next(); // means consider one word only
		//String str=sc.nextLine(); means remove spaces consider entire as string "white house" 
		 for(int i=str.length()-1;i>=0;i--) 
		 {
			 System.out.print(str.charAt(i)+" ");
		 }
		
		 //  String palindrome
		 
		 
		 
		 
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}

package practice;

import java.util.HashMap;

public class Test {

	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		/*
		 * int [] arr= {8,7,6,5,4,3,2,1};
		 * 
		 * int count=0; for(int i=0;i<arr.length;i++) { for(int j=i+1;j<arr.length;j++)
		 * { if(arr[i]+i==arr[j]+j) { count++; } } }
		 
		//System.out.println(count);
		
		String s1=new String("srinu");
		String s2=new String("srinu");
		
		System.out.println(s1.equals(s2)); // true same content for two objects
		
		
		
		System.out.println(s1==s2); // false s1 and s2 are different Adddress objects
		System.out.println(s1==s1);// true both are same address objects
		System.out.println(s2==s2); //true both are same address objects
		System.out.println(s2==s1);  //false s2 and s1 are different Adddress objects
		// in general "==" operator always checking address/Refference comparision
		//where "equals()" method checking content comparision 
		
		String str1="  hello       ";
		System.out.println(str1.strip());
		System.out.println(str1.stripLeading());
		
		
		System.out.print(str1.repeat(5) +" \t");
		
		
		
	}*/
	public static void main(String[] args)
    {
        A a = new B(); 
        a.print(); 
    }
}
class A 
{
	int i=2;
    public A() 
	{ 
    
		print();
	} 
    void print() 
	{ 
	  System.out.println("A ");
	}
}

class B extends A 
{
    int i = 4; 

    public B()
    { 
    	this.i=i;
        print();
    } 
    void print()
    { 
        System.out.print(super.i + " ");
    } 
}


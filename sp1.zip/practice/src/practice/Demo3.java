package practice;

public class Demo3{
	

	public static void main(String [] args)
	{
		
	}
	
	
	
		
		
	
}





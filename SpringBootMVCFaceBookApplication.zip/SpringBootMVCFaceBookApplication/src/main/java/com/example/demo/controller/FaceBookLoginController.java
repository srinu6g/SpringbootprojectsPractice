package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.service.LoginService;

import ch.qos.logback.core.model.Model;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class FaceBookLoginController {
	
	
	// connection/establosh dependency between controller and service
	@Autowired
	LoginService loginService;
	
	// loading my front part
	@RequestMapping("/load/details")
	public String loadMyLoginDetails()
	{
		return "login";
	}
	//  givinffg grepso adksk
	
	/*@RequestMapping(path="/sending",method = RequestMethod.POST)
	public ModelAndView GivingResponse()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("result");
		//TODO what ever requset coming front /view that req forwarding to service 
		// service to repository
		
		mv.addObject("result","User added success");
		
		return mv;
	}*/
	
	@RequestMapping(path="/click",method = RequestMethod.POST)
	public ModelAndView GivingResponse(HttpServletRequest  request)
	{
		ModelAndView  mv =new ModelAndView();
		mv.setViewName("result");
		
		
		//TODO what ever requset coming front /view that req forwarding to service 
		// service to repository
		
		String name=request.getParameter("fullname");
		String email= request.getParameter("email");
		
		// TODO forward to service layer
		
	String res=	loginService.createUserDetails(name,email);
		
	
		mv.addObject("result"," :: "+res);
		
		
		return mv;
	}
	
	
	
	
	
	

}

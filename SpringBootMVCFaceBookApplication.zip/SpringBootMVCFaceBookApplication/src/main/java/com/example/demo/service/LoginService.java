package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.LoginDetails;
import com.example.demo.repository.LoginRepository;

import jakarta.servlet.http.HttpServletRequest;

@Service
public class LoginService {
	
	
	// 
	@Autowired
	LoginRepository loginRepository;




	public String createUserDetails(String name, String email) {
		// TODO Auto-generated method stub

		//TODO forwarding to repositorerpe
		
		LoginDetails loginDetails=new LoginDetails();
		loginDetails.setName(name);
		loginDetails.setEmail(email);
		
		loginRepository.save(loginDetails);
		
		
		
		
		
		
		
		return "user details added success"+email;
	}
	
		

}
